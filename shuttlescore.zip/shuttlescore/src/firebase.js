import { initializeApp } from "firebase/app";
import { getFirestore, doc, onSnapshot, setDoc, getDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAh-O7VYp3difqPM7Zu_bhTvbfoURSdTNc",
  authDomain: "shuttlescore-98ba5.firebaseapp.com",
  projectId: "shuttlescore-98ba5",
  storageBucket: "shuttlescore-98ba5.firebasestorage.app",
  messagingSenderId: "719237539335",
  appId: "1:719237539335:web:2b7a6369a4854d79f52ca2"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

// References
export const liveMatchRef = () => doc(db, "shuttlescore", "live_match");
export const playersRef = () => doc(db, "shuttlescore", "players");
export const historyRef = () => doc(db, "shuttlescore", "match_history");

// Save live match state (called on every point)
export async function saveLiveMatch(state) {
  try {
    await setDoc(liveMatchRef(), { ...state, updatedAt: Date.now() });
  } catch (e) {
    console.error("Failed to save match:", e);
  }
}

// Save players list
export async function savePlayers(players) {
  try {
    await setDoc(playersRef(), { players, updatedAt: Date.now() });
  } catch (e) {
    console.error("Failed to save players:", e);
  }
}

// Save match history
export async function saveHistory(history) {
  try {
    await setDoc(historyRef(), { history, updatedAt: Date.now() });
  } catch (e) {
    console.error("Failed to save history:", e);
  }
}

// Subscribe to live match updates (for spectators)
export function subscribeLiveMatch(callback) {
  return onSnapshot(liveMatchRef(), (snap) => {
    if (snap.exists()) callback(snap.data());
  });
}

// Subscribe to players
export function subscribePlayers(callback) {
  return onSnapshot(playersRef(), (snap) => {
    if (snap.exists()) callback(snap.data().players || []);
  });
}

// Subscribe to history
export function subscribeHistory(callback) {
  return onSnapshot(historyRef(), (snap) => {
    if (snap.exists()) callback(snap.data().history || []);
  });
}
