import { useState, useEffect, useCallback, useRef } from "react";
import {
  saveLiveMatch, savePlayers, saveHistory,
  subscribeLiveMatch, subscribePlayers, subscribeHistory
} from "./firebase";

// ─── GAME LOGIC ───────────────────────────────────────────────────────────────
const WIN_BY = 2, MAX_PTS = 21, DEUCE_CAP = 30;

function gameWinner(a, b) {
  if ((a >= MAX_PTS || a === DEUCE_CAP) && a - b >= WIN_BY) return "A";
  if ((b >= MAX_PTS || b === DEUCE_CAP) && b - a >= WIN_BY) return "B";
  return null;
}
function matchWinner(sets, setsToWin) {
  const wA = sets.filter(s => s.winner === "A").length;
  const wB = sets.filter(s => s.winner === "B").length;
  if (wA >= setsToWin) return "A";
  if (wB >= setsToWin) return "B";
  return null;
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function makeDoublesTeams(players) {
  const s = shuffle(players);
  const teams = [];
  for (let i = 0; i + 1 < s.length; i += 2) teams.push([s[i], s[i + 1]]);
  if (s.length % 2 === 1) teams.push([s[s.length - 1]]);
  return teams;
}
function makeRoundRobinFixtures(teamNames) {
  const teams = [...teamNames];
  if (teams.length % 2 !== 0) teams.push("BYE");
  const rounds = teams.length - 1, half = teams.length / 2;
  const fixtures = [];
  for (let r = 0; r < rounds; r++) {
    const round = [];
    for (let i = 0; i < half; i++) {
      const a = teams[i], b = teams[teams.length - 1 - i];
      if (a !== "BYE" && b !== "BYE") round.push([a, b]);
    }
    fixtures.push(round);
    teams.splice(1, 0, teams.pop());
  }
  return fixtures;
}
function computeStats(history, players) {
  const pStats = {};
  players.forEach(p => { pStats[p] = { wins: 0, losses: 0, matches: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0 }; });
  const tStats = {};
  history.forEach(m => {
    const keyA = m.teamA.name, keyB = m.teamB.name;
    if (!tStats[keyA]) tStats[keyA] = { wins: 0, losses: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0, players: m.teamA.players };
    if (!tStats[keyB]) tStats[keyB] = { wins: 0, losses: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0, players: m.teamB.players };
    const aw = m.winner === "A";
    if (aw) { tStats[keyA].wins++; tStats[keyB].losses++; }
    else { tStats[keyB].wins++; tStats[keyA].losses++; }
    m.sets.forEach(s => {
      tStats[keyA].setsWon += s.winner === "A" ? 1 : 0; tStats[keyA].setsLost += s.winner === "B" ? 1 : 0;
      tStats[keyB].setsWon += s.winner === "B" ? 1 : 0; tStats[keyB].setsLost += s.winner === "A" ? 1 : 0;
      tStats[keyA].pointsWon += s.scoreA; tStats[keyA].pointsLost += s.scoreB;
      tStats[keyB].pointsWon += s.scoreB; tStats[keyB].pointsLost += s.scoreA;
    });
    [...m.teamA.players, ...m.teamB.players].forEach(p => {
      if (!pStats[p]) pStats[p] = { wins: 0, losses: 0, matches: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0 };
      pStats[p].matches++;
    });
    m.teamA.players.forEach(p => {
      if (!pStats[p]) pStats[p] = { wins: 0, losses: 0, matches: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0 };
      if (aw) pStats[p].wins++; else pStats[p].losses++;
      m.sets.forEach(s => { pStats[p].setsWon += s.winner === "A" ? 1 : 0; pStats[p].pointsWon += s.scoreA; pStats[p].pointsLost += s.scoreB; });
    });
    m.teamB.players.forEach(p => {
      if (!pStats[p]) pStats[p] = { wins: 0, losses: 0, matches: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0 };
      if (!aw) pStats[p].wins++; else pStats[p].losses++;
      m.sets.forEach(s => { pStats[p].setsWon += s.winner === "B" ? 1 : 0; pStats[p].pointsWon += s.scoreB; pStats[p].pointsLost += s.scoreA; });
    });
  });
  return { pStats, tStats };
}

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const C = {
  bg: "#060d14", surface: "#0d1b2a", card: "#112035", cardHover: "#162845",
  border: "#1e3a52", borderBright: "#2a5278",
  sideA: "#ff4d6d", sideADim: "#ff4d6d22",
  sideB: "#38b6ff", sideBDim: "#38b6ff22",
  court: "#0a5c2e", courtLine: "#1db954", courtLineDim: "#0d5229",
  net: "#e8f4f8", accent: "#ffe566", accentDim: "#ffe56622",
  green: "#1db954", greenDim: "#1db95422",
  text: "#e8f5ff", textMid: "#8db4cc", textDim: "#3d6880",
  win: "#22c55e", winDim: "#22c55e20", loss: "#ef4444", lossDim: "#ef444420",
  live: "#ff4444",
};

const css = `
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:${C.bg};color:${C.text};font-family:'DM Sans',sans-serif;min-height:100vh;overflow-x:hidden}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:${C.surface}}::-webkit-scrollbar-thumb{background:${C.border};border-radius:4px}
.app{max-width:860px;margin:0 auto;padding:12px 10px 80px}
.bot-nav{position:fixed;bottom:0;left:0;right:0;background:${C.surface};border-top:1px solid ${C.border};display:flex;z-index:50}
.bot-nav-btn{flex:1;padding:10px 4px 8px;border:none;background:transparent;color:${C.textDim};cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:3px;font-family:'DM Sans',sans-serif;font-size:10px;font-weight:600;letter-spacing:.3px;transition:color .2s;max-width:20%}
.bot-nav-btn.active{color:${C.courtLine}}
.bot-nav-icon{font-size:18px;line-height:1}
.header{display:flex;align-items:center;gap:10px;margin-bottom:18px;padding-top:4px}
.logo-mark{width:36px;height:36px;background:${C.courtLine};border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.logo-text{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;letter-spacing:-0.5px;line-height:1}
.logo-sub{font-size:11px;color:${C.textDim};font-weight:500;letter-spacing:1px;text-transform:uppercase}
/* LIVE BADGE */
.live-badge{display:inline-flex;align-items:center;gap:5px;background:${C.live}22;border:1px solid ${C.live}55;color:${C.live};padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.5px;margin-left:auto}
.live-dot{width:7px;height:7px;border-radius:50%;background:${C.live};animation:livePulse 1s ease-in-out infinite}
@keyframes livePulse{0%,100%{opacity:1}50%{opacity:.3}}
/* SPECTATOR BANNER */
.spectator-bar{background:${C.accentDim};border:1px solid ${C.accent}44;border-radius:12px;padding:10px 14px;margin-bottom:10px;display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:${C.accent}}
/* SYNC STATUS */
.sync-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.sync-dot.ok{background:${C.win}}
.sync-dot.err{background:${C.loss}}
.sync-dot.pending{background:${C.accent};animation:livePulse 1s infinite}
/* CARD */
.card{background:${C.card};border-radius:16px;border:1px solid ${C.border};overflow:hidden}
.card-pad{padding:16px}
.card+.card{margin-top:10px}
.eyebrow{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${C.textDim};margin-bottom:10px}
/* SCOREBOARD */
.scoreboard{background:linear-gradient(160deg,${C.card} 0%,${C.surface} 100%);border-radius:16px;border:1px solid ${C.border};padding:14px;margin-bottom:10px}
.sb-teams{display:grid;grid-template-columns:1fr auto 1fr;gap:8px;align-items:center;margin-bottom:14px}
.sb-team{display:flex;flex-direction:column;gap:3px}
.sb-team-b{align-items:flex-end;text-align:right}
.sb-team-name{font-family:'Syne',sans-serif;font-size:15px;font-weight:800;letter-spacing:-.3px}
.sb-team-players{font-size:11px;color:${C.textMid};line-height:1.5;font-weight:500}
.sb-set-pips{display:flex;gap:4px;margin-top:5px}
.sb-team-b .sb-set-pips{justify-content:flex-end}
.pip{width:12px;height:12px;border-radius:50%;border:1.5px solid ${C.border};transition:all .3s}
.pip.won-a{background:${C.sideA};border-color:${C.sideA};box-shadow:0 0 6px ${C.sideA}88}
.pip.won-b{background:${C.sideB};border-color:${C.sideB};box-shadow:0 0 6px ${C.sideB}88}
.sb-vs{display:flex;flex-direction:column;align-items:center;gap:3px}
.sb-vs-label{font-size:9px;font-weight:700;color:${C.textDim};letter-spacing:1px}
.sb-scores{display:flex;align-items:center;justify-content:center;gap:12px}
.score-big{font-family:'Syne',sans-serif;font-size:80px;font-weight:800;line-height:1;letter-spacing:-4px}
.score-big.a{color:${C.sideA};text-shadow:0 0 40px ${C.sideA}44}
.score-big.b{color:${C.sideB};text-shadow:0 0 40px ${C.sideB}44}
.score-divider{display:flex;flex-direction:column;align-items:center;gap:6px}
.serve-orb{width:10px;height:10px;border-radius:50%;background:${C.accent};animation:glow 1.2s ease-in-out infinite}
@keyframes glow{0%,100%{box-shadow:0 0 4px ${C.accent};opacity:1}50%{box-shadow:0 0 12px ${C.accent};opacity:.6}}
.score-line{width:2px;height:40px;background:${C.border};border-radius:1px}
.set-history{display:flex;justify-content:center;gap:8px;margin-top:10px;flex-wrap:wrap}
.set-badge{display:flex;align-items:center;gap:4px;background:${C.surface};border:1px solid ${C.border};border-radius:20px;padding:3px 10px;font-family:'JetBrains Mono',monospace;font-size:12px}
.set-num{font-size:9px;color:${C.textDim};margin-right:2px}
/* COURT */
.court-wrap{position:relative;border-radius:16px;overflow:hidden;margin-bottom:10px;user-select:none;cursor:pointer;touch-action:manipulation}
.court-tap{position:absolute;top:0;height:100%;display:flex;align-items:center;justify-content:center;transition:background .12s}
.court-tap:active{background:rgba(255,255,255,.08)}
.ripple-el{position:absolute;border-radius:50%;pointer-events:none;transform:translate(-50%,-50%);animation:rippleOut .55s ease-out forwards}
@keyframes rippleOut{0%{width:0;height:0;opacity:.8}100%{width:140px;height:140px;opacity:0}}
.point-toast{position:absolute;font-family:'Syne',sans-serif;font-size:28px;font-weight:800;pointer-events:none;animation:toastUp .7s ease-out forwards;letter-spacing:-1px}
@keyframes toastUp{0%{opacity:1;transform:translateY(0) scale(1)}100%{opacity:0;transform:translateY(-50px) scale(.8)}}
/* BUTTONS */
.btn{padding:9px 16px;border:none;border-radius:10px;cursor:pointer;font-family:'DM Sans',sans-serif;font-weight:600;font-size:13px;transition:all .18s;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
.btn-primary{background:${C.courtLine};color:#000}.btn-primary:hover{filter:brightness(1.1)}
.btn-accent{background:${C.accent};color:#000}.btn-accent:hover{filter:brightness(1.1)}
.btn-ghost{background:${C.card};color:${C.text};border:1px solid ${C.border}}.btn-ghost:hover{border-color:${C.borderBright};background:${C.cardHover}}
.btn-danger{background:${C.lossDim};color:${C.loss};border:1px solid ${C.loss}33}.btn-danger:hover{background:${C.loss}33}
.btn-sm{padding:6px 11px;font-size:12px;border-radius:8px}
.btn-xs{padding:4px 9px;font-size:11px;border-radius:7px}
.btn-full{width:100%;justify-content:center}
.btn:disabled{opacity:.4;cursor:not-allowed;pointer-events:none}
/* INPUTS */
.input{background:${C.surface};border:1.5px solid ${C.border};color:${C.text};padding:9px 12px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;transition:border .2s;width:100%}
.input:focus{border-color:${C.courtLine}}
.input::placeholder{color:${C.textDim}}
.input-row{display:flex;gap:8px;margin-bottom:10px}
.label-sm{font-size:11px;font-weight:600;color:${C.textDim};margin-bottom:5px}
.chip{display:inline-flex;align-items:center;gap:5px;background:${C.surface};border:1px solid ${C.border};padding:4px 10px;border-radius:20px;font-size:12px;font-weight:500;margin:3px}
.chip-x{background:none;border:none;color:${C.textDim};cursor:pointer;font-size:14px;line-height:1;padding:0}
.chip-x:hover{color:${C.loss}}
/* HISTORY */
.match-card{background:${C.card};border:1px solid ${C.border};border-radius:14px;padding:14px;margin-bottom:10px}
.mc-teams{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:10px}
.mc-team{flex:1}.mc-team-b{text-align:right}
.mc-name{font-family:'Syne',sans-serif;font-size:14px;font-weight:800}
.mc-players{font-size:11px;color:${C.textMid};margin-top:1px}
.mc-result-pips{display:flex;gap:4px;margin-top:6px}
.mc-result-pips.right{justify-content:flex-end}
.result-pip{width:10px;height:10px;border-radius:50%;background:${C.border}}
.result-pip.win{background:${C.win};box-shadow:0 0 5px ${C.win}66}
.result-pip.loss{background:${C.loss};box-shadow:0 0 5px ${C.loss}44}
.mc-sets{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:8px;padding-top:8px;border-top:1px solid ${C.border}}
.set-pill{display:flex;align-items:center;gap:3px;background:${C.surface};border-radius:6px;padding:3px 8px;font-family:'JetBrains Mono',monospace;font-size:12px}
.mc-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;margin-top:2px}
.mc-badge.win{background:${C.winDim};color:${C.win};border:1px solid ${C.win}33}
.mc-badge.type{background:${C.accentDim};color:${C.accent};border:1px solid ${C.accent}33;font-size:10px;letter-spacing:.5px}
/* STATS */
.stat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:8px}
.stat-box{background:${C.surface};border-radius:12px;padding:10px;text-align:center}
.stat-val{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;line-height:1;color:${C.accent}}
.stat-label{font-size:10px;color:${C.textDim};font-weight:600;margin-top:3px;letter-spacing:.5px;text-transform:uppercase}
.winrate-bar{height:5px;background:${C.border};border-radius:3px;overflow:hidden;margin:4px 0}
.winrate-fill{height:100%;background:linear-gradient(90deg,${C.courtLine},${C.accent});border-radius:3px;transition:width .5s ease}
.player-stat-card{background:${C.card};border:1px solid ${C.border};border-radius:14px;padding:14px;margin-bottom:8px}
.psc-header{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.avatar{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-weight:800;font-size:16px;flex-shrink:0}
.psc-name{font-family:'Syne',sans-serif;font-size:15px;font-weight:800}
/* TOURNAMENT */
.fixture-card{background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:11px 14px;margin-bottom:7px;display:flex;align-items:center;gap:8px}
.fix-team{font-weight:600;font-size:13px;flex:1;min-width:80px}
.fix-score-input{width:40px;text-align:center;background:${C.surface};border:1.5px solid ${C.border};color:${C.text};padding:5px;border-radius:7px;font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:600}
.fix-score-input:focus{border-color:${C.courtLine};outline:none}
.fix-winner-badge{font-size:10px;padding:2px 8px;border-radius:20px;background:${C.accentDim};color:${C.accent};border:1px solid ${C.accent}33;font-weight:700}
.standings-table{width:100%;border-collapse:collapse;font-size:12px}
.standings-table th{text-align:left;padding:5px 8px;color:${C.textDim};font-weight:700;font-size:10px;letter-spacing:.8px;text-transform:uppercase;border-bottom:1px solid ${C.border}}
.standings-table td{padding:7px 8px;border-bottom:1px solid ${C.border}44}
.standings-table tr:nth-child(1) td{color:${C.accent}}
.pts-cell{font-family:'JetBrains Mono',monospace;font-weight:700;color:${C.courtLine}}
/* TABS */
.tabs{display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap}
.tab{padding:7px 14px;border:1.5px solid ${C.border};border-radius:20px;cursor:pointer;font-size:12px;font-weight:700;font-family:'DM Sans',sans-serif;transition:all .2s;background:transparent;color:${C.textMid}}
.tab.active{background:${C.courtLine};color:#000;border-color:${C.courtLine}}
.divider{height:1px;background:${C.border};margin:14px 0}
/* WINNER */
.overlay{position:fixed;inset:0;background:#000c;display:flex;align-items:center;justify-content:center;z-index:200;animation:fadeIn .25s}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.winner-modal{background:${C.card};border-radius:24px;padding:32px 28px;text-align:center;border:1px solid ${C.courtLine}44;max-width:340px;width:90%;box-shadow:0 0 80px ${C.courtLine}22}
.trophy-big{font-size:60px;margin-bottom:6px;animation:bounce .6s ease-out}
@keyframes bounce{0%{transform:scale(0)}70%{transform:scale(1.15)}100%{transform:scale(1)}}
.winner-label{font-size:11px;font-weight:700;letter-spacing:2px;color:${C.textDim};text-transform:uppercase;margin-bottom:4px}
.winner-name{font-family:'Syne',sans-serif;font-size:34px;font-weight:800;letter-spacing:-1px;margin-bottom:4px}
.modal-btns{display:flex;gap:8px;justify-content:center}
.final-sets{display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-bottom:20px}
/* CONFIG */
.cfg-row{display:flex;gap:8px;margin-bottom:10px}
.cfg-opt{flex:1;padding:10px;border:1.5px solid ${C.border};border-radius:10px;background:transparent;color:${C.textMid};cursor:pointer;font-family:'DM Sans',sans-serif;font-weight:600;font-size:13px;transition:all .2s;text-align:center}
.cfg-opt.active{border-color:${C.courtLine};background:${C.greenDim};color:${C.courtLine}}
.ctrl-row{display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap}
.dbl-team{background:${C.surface};border:1px solid ${C.border};border-radius:12px;padding:10px 14px;margin-bottom:6px;display:flex;align-items:center;gap:10px}
.dbl-num{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:${C.accent};min-width:28px}
/* TOAST */
.toast{position:fixed;top:60px;left:50%;transform:translateX(-50%) translateY(-20px);background:${C.card};border:1px solid ${C.courtLine};color:${C.courtLine};padding:8px 20px;border-radius:20px;font-weight:600;font-size:13px;z-index:300;animation:toastIn .3s ease-out forwards;white-space:nowrap}
@keyframes toastIn{from{opacity:0;transform:translateX(-50%) translateY(-20px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
.empty{text-align:center;padding:32px 16px;color:${C.textDim}}
.empty-icon{font-size:40px;margin-bottom:8px;opacity:.5}
.empty-text{font-size:14px;font-weight:500}
.empty-sub{font-size:12px;margin-top:4px}
`;

// ─── COURT SVG ────────────────────────────────────────────────────────────────
function Court({ onScore, serving, disabled }) {
  const [effects, setEffects] = useState([]);
  const nextId = useRef(0);
  const handleClick = useCallback((side, e) => {
    if (disabled) return;
    const rect = e.currentTarget.closest(".court-wrap").getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    const id = nextId.current++;
    setEffects(ef => [...ef, { id, x, y, side }]);
    setTimeout(() => setEffects(ef => ef.filter(e => e.id !== id)), 700);
    onScore(side);
  }, [onScore, disabled]);
  return (
    <div className="court-wrap" style={{ opacity: disabled ? .5 : 1, pointerEvents: disabled ? "none" : "auto" }}>
      <svg viewBox="0 0 620 350" style={{ display: "block", width: "100%" }}>
        <defs>
          <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0a5c2e" /><stop offset="100%" stopColor="#083d1f" />
          </linearGradient>
        </defs>
        <rect width="620" height="350" fill="url(#cg)" />
        <rect x="30" y="22" width="560" height="306" fill="none" stroke={C.courtLine} strokeWidth="2.5" opacity=".9" />
        <rect x="68" y="22" width="484" height="306" fill="none" stroke={C.courtLineDim} strokeWidth="1.5" opacity=".7" />
        <line x1="30" y1="52" x2="590" y2="52" stroke={C.courtLineDim} strokeWidth="1.2" opacity=".5" strokeDasharray="5,5" />
        <line x1="30" y1="298" x2="590" y2="298" stroke={C.courtLineDim} strokeWidth="1.2" opacity=".5" strokeDasharray="5,5" />
        <line x1="30" y1="112" x2="590" y2="112" stroke={C.courtLine} strokeWidth="1.5" opacity=".7" />
        <line x1="30" y1="238" x2="590" y2="238" stroke={C.courtLine} strokeWidth="1.5" opacity=".7" />
        <line x1="310" y1="112" x2="310" y2="238" stroke={C.courtLine} strokeWidth="1.5" opacity=".6" />
        <rect x="304" y="16" width="12" height="318" fill="rgba(255,255,255,.06)" rx="2" />
        <line x1="310" y1="16" x2="310" y2="334" stroke={C.net} strokeWidth="3" opacity=".85" />
        <circle cx="310" cy="16" r="5" fill={C.net} opacity=".6" />
        <circle cx="310" cy="334" r="5" fill={C.net} opacity=".6" />
        {serving === "A" && <circle cx="170" cy="175" r="9" fill={C.accent} opacity=".9"><animate attributeName="r" values="9;11;9" dur="1.1s" repeatCount="indefinite" /><animate attributeName="opacity" values=".9;.5;.9" dur="1.1s" repeatCount="indefinite" /></circle>}
        {serving === "B" && <circle cx="450" cy="175" r="9" fill={C.accent} opacity=".9"><animate attributeName="r" values="9;11;9" dur="1.1s" repeatCount="indefinite" /><animate attributeName="opacity" values=".9;.5;.9" dur="1.1s" repeatCount="indefinite" /></circle>}
        <text x="170" y="175" textAnchor="middle" dominantBaseline="middle" fill={C.sideA} opacity=".18" style={{ fontSize: 40, fontFamily: "Syne, sans-serif", fontWeight: 800, letterSpacing: 2 }}>TAP</text>
        <text x="450" y="175" textAnchor="middle" dominantBaseline="middle" fill={C.sideB} opacity=".18" style={{ fontSize: 40, fontFamily: "Syne, sans-serif", fontWeight: 800, letterSpacing: 2 }}>TAP</text>
      </svg>
      <div className="court-tap" style={{ left: 0, width: "50%" }} onClick={e => handleClick("A", e)} />
      <div className="court-tap" style={{ right: 0, width: "50%" }} onClick={e => handleClick("B", e)} />
      {effects.map(ef => (
        <div key={ef.id}>
          <div className="ripple-el" style={{ left: ef.x, top: ef.y, background: ef.side === "A" ? C.sideA : C.sideB }} />
          <div className="point-toast" style={{ left: ef.x - 20, top: ef.y - 20, color: ef.side === "A" ? C.sideA : C.sideB }}>+1</div>
        </div>
      ))}
    </div>
  );
}

// ─── SCOREBOARD ───────────────────────────────────────────────────────────────
function Scoreboard({ teamA, teamB, scoreA, scoreB, sets, serving, setsToWin }) {
  const wA = sets.filter(s => s.winner === "A").length;
  const wB = sets.filter(s => s.winner === "B").length;
  return (
    <div className="scoreboard">
      <div className="sb-teams">
        <div className="sb-team">
          <div className="sb-team-name" style={{ color: C.sideA }}>{teamA.name || "Team A"}</div>
          <div className="sb-team-players">{teamA.players.join(" / ")}</div>
          <div className="sb-set-pips">{Array.from({ length: setsToWin }).map((_, i) => <div key={i} className={`pip ${wA > i ? "won-a" : ""}`} />)}</div>
        </div>
        <div className="sb-vs">
          <div className="sb-vs-label">{teamA.type === "doubles" ? "DOUBLES" : "SINGLES"}</div>
          <div style={{ fontSize: 11, color: C.textDim, fontWeight: 700 }}>SET {sets.length + 1}</div>
        </div>
        <div className="sb-team sb-team-b">
          <div className="sb-team-name" style={{ color: C.sideB }}>{teamB.name || "Team B"}</div>
          <div className="sb-team-players">{teamB.players.join(" / ")}</div>
          <div className="sb-set-pips">{Array.from({ length: setsToWin }).map((_, i) => <div key={i} className={`pip ${wB > i ? "won-b" : ""}`} />)}</div>
        </div>
      </div>
      <div className="sb-scores">
        <div className="score-big a">{scoreA}</div>
        <div className="score-divider">
          {serving === "A" ? <div className="serve-orb" /> : <div style={{ width: 10, height: 10 }} />}
          <div className="score-line" />
          {serving === "B" ? <div className="serve-orb" /> : <div style={{ width: 10, height: 10 }} />}
        </div>
        <div className="score-big b">{scoreB}</div>
      </div>
      {sets.length > 0 && (
        <div className="set-history">
          {sets.map((s, i) => (
            <div key={i} className="set-badge">
              <span className="set-num">S{i + 1}</span>
              <span style={{ color: s.winner === "A" ? C.sideA : C.textDim, fontWeight: s.winner === "A" ? 700 : 400 }}>{s.scoreA}</span>
              <span style={{ color: C.textDim }}>–</span>
              <span style={{ color: s.winner === "B" ? C.sideB : C.textDim, fontWeight: s.winner === "B" ? 700 : 400 }}>{s.scoreB}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── STATS ────────────────────────────────────────────────────────────────────
function StatsView({ history, players }) {
  const [tab, setTab] = useState("players");
  const { pStats, tStats } = computeStats(history, players);
  const avatarColors = [C.sideA, C.sideB, C.courtLine, C.accent, "#b47dff", "#ff8c42", "#00d4aa"];
  if (history.length === 0) return (
    <div className="empty"><div className="empty-icon">📊</div><div className="empty-text">No match data yet</div><div className="empty-sub">Play some matches to see stats here</div></div>
  );
  return (
    <>
      <div className="tabs">
        <button className={`tab ${tab === "players" ? "active" : ""}`} onClick={() => setTab("players")}>Players</button>
        <button className={`tab ${tab === "teams" ? "active" : ""}`} onClick={() => setTab("teams")}>Teams</button>
      </div>
      {tab === "players" && Object.entries(pStats).filter(([, s]) => s.matches > 0).sort((a, b) => b[1].wins - a[1].wins).map(([name, s], i) => {
        const wr = s.matches > 0 ? Math.round((s.wins / s.matches) * 100) : 0;
        const color = avatarColors[i % avatarColors.length];
        return (
          <div key={name} className="player-stat-card">
            <div className="psc-header">
              <div className="avatar" style={{ background: color + "33", color, border: `2px solid ${color}44` }}>{name[0].toUpperCase()}</div>
              <div style={{ flex: 1 }}>
                <div className="psc-name">{name}</div>
                <div style={{ fontSize: 11, color: C.textMid }}>{s.wins}W – {s.losses}L · {s.matches} matches</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontSize: 22, fontWeight: 800, color }}>{wr}%</div>
                <div style={{ fontSize: 10, color: C.textDim }}>WIN RATE</div>
              </div>
            </div>
            <div className="winrate-bar"><div className="winrate-fill" style={{ width: `${wr}%` }} /></div>
            <div className="stat-grid" style={{ marginTop: 10 }}>
              <div className="stat-box"><div className="stat-val" style={{ color: C.win }}>{s.wins}</div><div className="stat-label">Wins</div></div>
              <div className="stat-box"><div className="stat-val">{s.setsWon}</div><div className="stat-label">Sets Won</div></div>
              <div className="stat-box"><div className="stat-val" style={{ color: C.courtLine }}>{s.pointsWon}</div><div className="stat-label">Points</div></div>
            </div>
          </div>
        );
      })}
      {tab === "teams" && Object.entries(tStats).sort((a, b) => b[1].wins - a[1].wins).map(([name, s]) => {
        const total = s.wins + s.losses;
        const wr = total > 0 ? Math.round((s.wins / total) * 100) : 0;
        return (
          <div key={name} className="player-stat-card">
            <div className="psc-header">
              <div className="avatar" style={{ background: C.accentDim, color: C.accent, border: `2px solid ${C.accent}44` }}>🏸</div>
              <div style={{ flex: 1 }}>
                <div className="psc-name">{name}</div>
                <div style={{ fontSize: 11, color: C.textMid }}>{s.players?.join(" & ")} · {total} matches</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontSize: 22, fontWeight: 800, color: C.accent }}>{wr}%</div>
                <div style={{ fontSize: 10, color: C.textDim }}>WIN RATE</div>
              </div>
            </div>
            <div className="winrate-bar"><div className="winrate-fill" style={{ width: `${wr}%` }} /></div>
            <div className="stat-grid" style={{ marginTop: 10 }}>
              <div className="stat-box"><div className="stat-val" style={{ color: C.win }}>{s.wins}</div><div className="stat-label">Wins</div></div>
              <div className="stat-box"><div className="stat-val">{s.setsWon}</div><div className="stat-label">Sets Won</div></div>
              <div className="stat-box"><div className="stat-val" style={{ color: C.courtLine }}>{s.pointsWon}</div><div className="stat-label">Points</div></div>
            </div>
          </div>
        );
      })}
    </>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
const REFEREE_CODE = "smash";   // friends can't accidentally edit scores

export default function App() {
  const [view, setView] = useState("match");
  const [setupStep, setSetupStep] = useState(0);
  const [toast, setToast] = useState(null);
  const [isReferee, setIsReferee] = useState(false);
  const [codeInput, setCodeInput] = useState("");
  const [syncStatus, setSyncStatus] = useState("pending"); // ok | err | pending

  // Data (synced from Firebase)
  const [players, setPlayers] = useState(["Alice", "Bob", "Charlie", "Diana", "Eve", "Frank"]);
  const [history, setHistory] = useState([]);

  // Live match state
  const [teamA, setTeamA] = useState({ name: "Red", players: ["Alice"], type: "singles" });
  const [teamB, setTeamB] = useState({ name: "Blue", players: ["Bob"], type: "singles" });
  const [scoreA, setScoreA] = useState(0);
  const [scoreB, setScoreB] = useState(0);
  const [serving, setServing] = useState("A");
  const [sets, setSets] = useState([]);
  const [winner, setWinner] = useState(null);
  const [lastPoint, setLastPoint] = useState(null);
  const [matchSetsToWin, setMatchSetsToWin] = useState(2);
  const [matchStatus, setMatchStatus] = useState("idle"); // idle | live | finished

  // Setup config
  const [matchType, setMatchType] = useState("singles");
  const [setsToWin, setSetsToWin] = useState(2);
  const [teamAName, setTeamAName] = useState("Red");
  const [teamBName, setTeamBName] = useState("Blue");
  const [selA, setSelA] = useState([]);
  const [selB, setSelB] = useState([]);
  const maxPerSide = matchType === "doubles" ? 2 : 1;
  const [playerInput, setPlayerInput] = useState("");
  const [doublesTeams, setDoublesTeams] = useState([]);
  const [doublesReady, setDoublesReady] = useState(false);

  // Tournament
  const [tournTeams, setTournTeams] = useState([]);
  const [tournInput, setTournInput] = useState("");
  const [fixtures, setFixtures] = useState([]);
  const [fixScores, setFixScores] = useState({});
  const [tournStarted, setTournStarted] = useState(false);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  // ── Firebase subscriptions ──
  useEffect(() => {
    const unsubs = [];
    // Players
    unsubs.push(subscribePlayers(p => { setPlayers(p); setSyncStatus("ok"); }));
    // History
    unsubs.push(subscribeHistory(h => { setHistory(h); setSyncStatus("ok"); }));
    // Live match
    unsubs.push(subscribeLiveMatch(data => {
      setSyncStatus("ok");
      if (!isReferee) {
        // Spectators receive all state
        setTeamA(data.teamA || teamA);
        setTeamB(data.teamB || teamB);
        setScoreA(data.scoreA ?? 0);
        setScoreB(data.scoreB ?? 0);
        setServing(data.serving || "A");
        setSets(data.sets || []);
        setWinner(data.winner || null);
        setMatchSetsToWin(data.setsToWin || 2);
        setMatchStatus(data.status || "idle");
      }
    }));
    return () => unsubs.forEach(u => u());
  }, [isReferee]); // eslint-disable-line

  // ── Push live state to Firebase whenever score changes (referee only) ──
  const pushMatchState = useCallback((state) => {
    setSyncStatus("pending");
    saveLiveMatch(state).then(() => setSyncStatus("ok")).catch(() => setSyncStatus("err"));
  }, []);

  const handleScore = useCallback((side) => {
    if (winner || !isReferee) return;
    setLastPoint(side);
    const nA = scoreA + (side === "A" ? 1 : 0);
    const nB = scoreB + (side === "B" ? 1 : 0);
    const gw = gameWinner(nA, nB);
    if (gw) {
      const newSets = [...sets, { scoreA: nA, scoreB: nB, winner: gw }];
      setSets(newSets);
      const mw = matchWinner(newSets, matchSetsToWin);
      if (mw) {
        setWinner(mw);
        const newHistory = [{ teamA, teamB, sets: newSets, winner: mw, type: teamA.type, date: Date.now() }, ...history];
        setHistory(newHistory);
        saveHistory(newHistory);
        setMatchStatus("finished");
        pushMatchState({ teamA, teamB, scoreA: nA, scoreB: nB, sets: newSets, serving, winner: mw, setsToWin: matchSetsToWin, status: "finished" });
      } else {
        setScoreA(0); setScoreB(0); setServing(gw);
        pushMatchState({ teamA, teamB, scoreA: 0, scoreB: 0, sets: newSets, serving: gw, winner: null, setsToWin: matchSetsToWin, status: "live" });
      }
    } else {
      setScoreA(nA); setScoreB(nB); setServing(side);
      pushMatchState({ teamA, teamB, scoreA: nA, scoreB: nB, sets, serving: side, winner: null, setsToWin: matchSetsToWin, status: "live" });
    }
  }, [scoreA, scoreB, sets, winner, teamA, teamB, matchSetsToWin, serving, history, isReferee, pushMatchState]);

  const undoPoint = () => {
    if (!isReferee || winner) return;
    let nA = scoreA, nB = scoreB, newSets = sets;
    if (scoreA === 0 && scoreB === 0 && sets.length > 0) {
      const prev = sets[sets.length - 1];
      newSets = sets.slice(0, -1);
      nA = prev.scoreA - (lastPoint === "A" ? 1 : 0);
      nB = prev.scoreB - (lastPoint === "B" ? 1 : 0);
      setSets(newSets); setScoreA(nA); setScoreB(nB);
    } else {
      if (lastPoint === "A") { nA = Math.max(0, scoreA - 1); setScoreA(nA); }
      else if (lastPoint === "B") { nB = Math.max(0, scoreB - 1); setScoreB(nB); }
    }
    pushMatchState({ teamA, teamB, scoreA: nA, scoreB: nB, sets: newSets, serving, winner: null, setsToWin: matchSetsToWin, status: "live" });
  };

  const resetMatch = (keepTeams = true) => {
    setScoreA(0); setScoreB(0); setSets([]); setWinner(null); setServing("A"); setLastPoint(null); setMatchStatus("idle");
    if (isReferee) pushMatchState({ teamA, teamB, scoreA: 0, scoreB: 0, sets: [], serving: "A", winner: null, setsToWin: matchSetsToWin, status: "idle" });
  };

  const startMatch = () => {
    if (selA.length === 0 || selB.length === 0) { showToast("Select players for both sides"); return; }
    const tA = { name: teamAName || selA.join(" & "), players: selA, type: matchType };
    const tB = { name: teamBName || selB.join(" & "), players: selB, type: matchType };
    setTeamA(tA); setTeamB(tB); setMatchSetsToWin(setsToWin);
    setScoreA(0); setScoreB(0); setSets([]); setWinner(null); setServing("A"); setLastPoint(null); setMatchStatus("live");
    pushMatchState({ teamA: tA, teamB: tB, scoreA: 0, scoreB: 0, sets: [], serving: "A", winner: null, setsToWin, status: "live" });
    setView("match"); setSetupStep(0);
  };

  const addPlayer = () => {
    const n = playerInput.trim();
    if (!n || players.includes(n)) { showToast("Already exists"); return; }
    const newP = [...players, n];
    setPlayers(newP); savePlayers(newP); setPlayerInput("");
  };
  const removePlayer = (name) => {
    const newP = players.filter(x => x !== name);
    setPlayers(newP); savePlayers(newP);
    setSelA(a => a.filter(x => x !== name));
    setSelB(b => b.filter(x => x !== name));
  };
  const toggleSel = (side, name) => {
    if (side === "A") setSelA(a => a.includes(name) ? a.filter(x => x !== name) : [...a, name]);
    else setSelB(b => b.includes(name) ? b.filter(x => x !== name) : [...b, name]);
  };

  const addTournTeam = () => {
    const n = tournInput.trim();
    if (!n || tournTeams.includes(n)) return;
    setTournTeams(t => [...t, n]); setTournInput("");
  };
  const startTournament = () => {
    const f = makeRoundRobinFixtures(tournTeams);
    setFixtures(f);
    const sc = {};
    f.forEach((r, ri) => r.forEach((_, mi) => { sc[`${ri}-${mi}`] = { a: "", b: "" }; }));
    setFixScores(sc); setTournStarted(true);
  };
  const fixWinner = (key, match) => {
    const sc = fixScores[key];
    if (!sc || sc.a === "" || sc.b === "") return null;
    const a = parseInt(sc.a), b = parseInt(sc.b);
    if (isNaN(a) || isNaN(b)) return null;
    if (a > b) return match[0]; if (b > a) return match[1]; return "draw";
  };
  const standings = () => {
    const table = {};
    tournTeams.forEach(t => table[t] = { w: 0, l: 0, d: 0, pts: 0, f: 0, a: 0 });
    fixtures.forEach((round, ri) => round.forEach((match, mi) => {
      const key = `${ri}-${mi}`;
      const sc = fixScores[key];
      if (!sc || sc.a === "" || sc.b === "") return;
      const a = parseInt(sc.a), b = parseInt(sc.b);
      if (isNaN(a) || isNaN(b)) return;
      table[match[0]].f += a; table[match[0]].a += b;
      table[match[1]].f += b; table[match[1]].a += a;
      if (a > b) { table[match[0]].w++; table[match[0]].pts += 3; table[match[1]].l++; }
      else if (b > a) { table[match[1]].w++; table[match[1]].pts += 3; table[match[0]].l++; }
      else { table[match[0]].d++; table[match[0]].pts++; table[match[1]].d++; table[match[1]].pts++; }
    }));
    return Object.entries(table).sort((a, b) => b[1].pts - a[1].pts);
  };

  const navItems = [
    { id: "match", icon: "🏸", label: "Match" },
    { id: "setup", icon: "⚙️", label: "Setup" },
    { id: "tournament", icon: "🏆", label: "Tourn." },
    { id: "stats", icon: "📊", label: "Stats" },
    { id: "history", icon: "📋", label: "History" },
  ];

  const syncColor = syncStatus === "ok" ? C.win : syncStatus === "err" ? C.loss : C.accent;

  return (
    <>
      <style>{css}</style>
      <div className="app">
        {/* Header */}
        <div className="header">
          <div className="logo-mark">🏸</div>
          <div>
            <div className="logo-text">SHUTTLE<span style={{ color: C.courtLine }}>SCORE</span></div>
            <div className="logo-sub">Live Badminton Tracker</div>
          </div>
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
            {/* Sync indicator */}
            <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 10, color: C.textDim }}>
              <div className={`sync-dot ${syncStatus}`} />
              {syncStatus === "ok" ? "Synced" : syncStatus === "err" ? "Offline" : "Syncing…"}
            </div>
            {/* Referee toggle */}
            {isReferee
              ? <div style={{ display: "flex", alignItems: "center", gap: 5, background: C.greenDim, border: `1px solid ${C.courtLine}44`, padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, color: C.courtLine }}>
                  ✏️ Referee
                  <button onClick={() => setIsReferee(false)} style={{ background: "none", border: "none", color: C.textDim, cursor: "pointer", fontSize: 12, padding: 0 }}>×</button>
                </div>
              : <button className="btn btn-ghost btn-xs" onClick={() => setView("login")}>🔐 Ref login</button>
            }
          </div>
        </div>

        {/* Spectator banner */}
        {!isReferee && matchStatus === "live" && view === "match" && (
          <div className="spectator-bar">
            <div className="live-dot" />
            <span>LIVE — Spectator mode. Scores update automatically.</span>
          </div>
        )}

        {/* ── LOGIN ── */}
        {view === "login" && (
          <div className="card card-pad" style={{ maxWidth: 340, margin: "0 auto", marginTop: 40 }}>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ fontSize: 40 }}>🏸</div>
              <div style={{ fontFamily: "Syne, sans-serif", fontSize: 20, fontWeight: 800, marginTop: 8 }}>Referee Login</div>
              <div style={{ fontSize: 12, color: C.textDim, marginTop: 4 }}>Enter the code to control the scoreboard</div>
            </div>
            <input
              className="input"
              type="password"
              placeholder="Enter referee code…"
              value={codeInput}
              onChange={e => setCodeInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter") {
                  if (codeInput === REFEREE_CODE) { setIsReferee(true); setView("match"); showToast("Welcome, referee! 🏸"); }
                  else { showToast("Wrong code"); setCodeInput(""); }
                }
              }}
              style={{ marginBottom: 10 }}
            />
            <button className="btn btn-primary btn-full" onClick={() => {
              if (codeInput === REFEREE_CODE) { setIsReferee(true); setView("match"); showToast("Welcome, referee! 🏸"); }
              else { showToast("Wrong code"); setCodeInput(""); }
            }}>Enter</button>
            <button className="btn btn-ghost btn-full" style={{ marginTop: 8 }} onClick={() => setView("match")}>Watch as spectator</button>
            <div style={{ marginTop: 16, padding: "10px", background: C.surface, borderRadius: 8, fontSize: 11, color: C.textDim }}>
              💡 Default code is <strong style={{ color: C.text }}>smash</strong> — change the <code>REFEREE_CODE</code> constant in App.js before deploying
            </div>
          </div>
        )}

        {/* ── MATCH ── */}
        {view === "match" && (
          <>
            <Scoreboard teamA={teamA} teamB={teamB} scoreA={scoreA} scoreB={scoreB} sets={sets} serving={serving} setsToWin={matchSetsToWin} />
            <Court onScore={handleScore} serving={serving} disabled={!!winner || !isReferee} />
            {isReferee ? (
              <div className="ctrl-row">
                <button className="btn btn-danger btn-sm" onClick={undoPoint} disabled={scoreA === 0 && scoreB === 0 && sets.length === 0}>↩ Undo</button>
                <button className="btn btn-ghost btn-sm" onClick={() => { setServing(s => s === "A" ? "B" : "A"); }}>🔄 Swap serve</button>
                <div style={{ flex: 1 }} />
                <button className="btn btn-ghost btn-sm" onClick={() => resetMatch()}>↺ Reset</button>
                <button className="btn btn-accent btn-sm" onClick={() => { setView("setup"); setSetupStep(0); }}>+ Setup</button>
              </div>
            ) : (
              <div style={{ textAlign: "center", color: C.textDim, fontSize: 12, padding: "8px 0" }}>
                👀 Watching live — only the referee can score
              </div>
            )}
            {isReferee && <div style={{ textAlign: "center", color: C.textDim, fontSize: 11, marginTop: -2 }}>Tap court to score · Yellow dot = server</div>}
          </>
        )}

        {/* ── SETUP ── */}
        {view === "setup" && isReferee && (
          <>
            {setupStep === 0 && (
              <div className="card card-pad">
                <div className="eyebrow">Match Format</div>
                <div className="cfg-row">
                  <button className={`cfg-opt ${matchType === "singles" ? "active" : ""}`} onClick={() => { setMatchType("singles"); setSelA([]); setSelB([]); }}>🏃 Singles<br /><span style={{ fontSize: 11, fontWeight: 400 }}>1 vs 1</span></button>
                  <button className={`cfg-opt ${matchType === "doubles" ? "active" : ""}`} onClick={() => { setMatchType("doubles"); setSelA([]); setSelB([]); }}>👥 Doubles<br /><span style={{ fontSize: 11, fontWeight: 400 }}>2 vs 2</span></button>
                </div>
                <div className="eyebrow" style={{ marginTop: 16 }}>Best Of</div>
                <div className="cfg-row">
                  {[1, 2, 3].map(n => (
                    <button key={n} className={`cfg-opt ${setsToWin === n ? "active" : ""}`} onClick={() => setSetsToWin(n)}>
                      {n === 1 ? "1 Set" : n === 2 ? "Best of 3" : "Best of 5"}<br /><span style={{ fontSize: 11, fontWeight: 400 }}>{n} set{n > 1 ? "s to win" : ""}</span>
                    </button>
                  ))}
                </div>
                <button className="btn btn-primary btn-full" style={{ marginTop: 16 }} onClick={() => setSetupStep(1)}>Next: Pick Players →</button>
              </div>
            )}
            {setupStep === 1 && (
              <div className="card card-pad">
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                  <button className="btn btn-ghost btn-sm" onClick={() => setSetupStep(0)}>← Back</button>
                  <div className="eyebrow" style={{ marginBottom: 0 }}>Select Players · {matchType === "doubles" ? "2 per side" : "1 per side"}</div>
                </div>
                {players.length === 0 ? (
                  <div className="empty"><div className="empty-icon">👤</div><div className="empty-text">No players registered</div><div className="empty-sub">Add players below first</div></div>
                ) : (
                  <>
                    <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
                      <div style={{ flex: 1, background: C.sideADim, border: `1px solid ${C.sideA}44`, borderRadius: 10, padding: "8px 12px" }}>
                        <div className="label-sm" style={{ color: C.sideA }}>Side A · {selA.length}/{maxPerSide}</div>
                        <div style={{ fontWeight: 700, fontSize: 13, minHeight: 18 }}>{selA.join(" & ") || "—"}</div>
                      </div>
                      <div style={{ flex: 1, background: C.sideBDim, border: `1px solid ${C.sideB}44`, borderRadius: 10, padding: "8px 12px" }}>
                        <div className="label-sm" style={{ color: C.sideB }}>Side B · {selB.length}/{maxPerSide}</div>
                        <div style={{ fontWeight: 700, fontSize: 13, minHeight: 18, textAlign: "right" }}>{selB.join(" & ") || "—"}</div>
                      </div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                      {players.map(p => {
                        const isA = selA.includes(p), isB = selB.includes(p);
                        return (
                          <div key={p} style={{ display: "flex", alignItems: "center", gap: 8, background: C.surface, borderRadius: 10, padding: "8px 12px", border: `1px solid ${isA ? C.sideA + "44" : isB ? C.sideB + "44" : C.border}` }}>
                            <div style={{ flex: 1, fontWeight: 600, fontSize: 13 }}>{p}</div>
                            <button className={`btn btn-sm`} style={isA ? { background: C.sideA, color: "#fff" } : { background: C.card, border: `1px solid ${C.border}`, color: C.text }} onClick={() => toggleSel("A", p)} disabled={isB || (!isA && selA.length >= maxPerSide)}>A</button>
                            <button className={`btn btn-sm`} style={isB ? { background: C.sideB, color: "#fff" } : { background: C.card, border: `1px solid ${C.border}`, color: C.text }} onClick={() => toggleSel("B", p)} disabled={isA || (!isB && selB.length >= maxPerSide)}>B</button>
                          </div>
                        );
                      })}
                    </div>
                    <div className="divider" />
                    <button className="btn btn-primary btn-full" onClick={() => setSetupStep(2)} disabled={selA.length === 0 || selB.length === 0}>Next: Name Teams →</button>
                  </>
                )}
                <div className="divider" />
                <div className="eyebrow">Manage Players</div>
                <div className="input-row">
                  <input className="input" value={playerInput} onChange={e => setPlayerInput(e.target.value)} onKeyDown={e => e.key === "Enter" && addPlayer()} placeholder="Add new player…" />
                  <button className="btn btn-primary" style={{ whiteSpace: "nowrap" }} onClick={addPlayer}>Add</button>
                </div>
                <div>{players.map(p => <span key={p} className="chip">{p}<button className="chip-x" onClick={() => removePlayer(p)}>×</button></span>)}</div>
              </div>
            )}
            {setupStep === 2 && (
              <div className="card card-pad">
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                  <button className="btn btn-ghost btn-sm" onClick={() => setSetupStep(1)}>← Back</button>
                  <div className="eyebrow" style={{ marginBottom: 0 }}>Team Names</div>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <div className="label-sm" style={{ color: C.sideA }}>Side A – {selA.join(" & ")}</div>
                  <input className="input" value={teamAName} onChange={e => setTeamAName(e.target.value)} placeholder="Team name (optional)" />
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div className="label-sm" style={{ color: C.sideB }}>Side B – {selB.join(" & ")}</div>
                  <input className="input" value={teamBName} onChange={e => setTeamBName(e.target.value)} placeholder="Team name (optional)" />
                </div>
                <div style={{ background: C.surface, borderRadius: 10, padding: "10px 12px", marginBottom: 16, fontSize: 12, color: C.textMid }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span>Format</span><span style={{ color: C.text, fontWeight: 600 }}>{matchType === "doubles" ? "Doubles (2v2)" : "Singles (1v1)"}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span>Sets</span><span style={{ color: C.text, fontWeight: 600 }}>{setsToWin === 1 ? "1 Set" : setsToWin === 2 ? "Best of 3" : "Best of 5"}</span>
                  </div>
                </div>
                <button className="btn btn-accent btn-full" onClick={startMatch}>▶ Start Match — Go Live</button>
              </div>
            )}
            {/* Random doubles */}
            <div className="card card-pad" style={{ marginTop: 10 }}>
              <div className="eyebrow">Random Doubles Generator</div>
              <button className="btn btn-ghost btn-full" onClick={() => { setDoublesTeams(makeDoublesTeams(players)); setDoublesReady(true); showToast("Teams shuffled!"); }}>🔀 Shuffle Teams</button>
              {doublesReady && doublesTeams.map((team, i) => (
                <div key={i} className="dbl-team" style={{ marginTop: i === 0 ? 10 : 0 }}>
                  <div className="dbl-num">{i + 1}</div>
                  <div style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{team.join(" & ")}</div>
                </div>
              ))}
            </div>
          </>
        )}
        {view === "setup" && !isReferee && (
          <div className="card card-pad" style={{ textAlign: "center", padding: "40px 20px" }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔐</div>
            <div style={{ fontFamily: "Syne, sans-serif", fontSize: 18, fontWeight: 800, marginBottom: 8 }}>Referee Only</div>
            <div style={{ color: C.textDim, fontSize: 13, marginBottom: 16 }}>Log in as referee to set up and control matches</div>
            <button className="btn btn-primary" onClick={() => setView("login")}>Referee Login</button>
          </div>
        )}

        {/* ── TOURNAMENT ── */}
        {view === "tournament" && (
          <>
            {!tournStarted ? (
              <div className="card card-pad">
                <div className="eyebrow">Tournament · Round Robin</div>
                <div className="input-row">
                  <input className="input" value={tournInput} onChange={e => setTournInput(e.target.value)} onKeyDown={e => e.key === "Enter" && addTournTeam()} placeholder="Add team or player name…" />
                  <button className="btn btn-primary" style={{ whiteSpace: "nowrap" }} onClick={addTournTeam}>Add</button>
                </div>
                <div style={{ marginBottom: 12 }}>{tournTeams.map(t => <span key={t} className="chip">{t}<button className="chip-x" onClick={() => setTournTeams(x => x.filter(y => y !== t))}>×</button></span>)}</div>
                {tournTeams.length >= 2
                  ? <button className="btn btn-accent btn-full" onClick={startTournament}>🏆 Generate Fixtures</button>
                  : <div style={{ color: C.textDim, fontSize: 12, textAlign: "center" }}>Add at least 2 teams</div>}
              </div>
            ) : (
              <>
                <div className="card card-pad">
                  <div className="eyebrow">Standings</div>
                  <table className="standings-table">
                    <thead><tr><th>#</th><th>Team</th><th>W</th><th>D</th><th>L</th><th>F</th><th>A</th><th>Pts</th></tr></thead>
                    <tbody>
                      {standings().map(([team, s], i) => (
                        <tr key={team}>
                          <td style={{ color: C.textDim, fontWeight: 600 }}>{i + 1}</td>
                          <td style={{ fontWeight: 600 }}>{team}</td>
                          <td>{s.w}</td><td>{s.d}</td><td>{s.l}</td><td>{s.f}</td><td>{s.a}</td>
                          <td className="pts-cell">{s.pts}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="card card-pad" style={{ marginTop: 10 }}>
                  <div className="eyebrow">Fixtures</div>
                  {fixtures.map((round, ri) => (
                    <div key={ri} style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 11, color: C.textDim, fontWeight: 700, marginBottom: 6, letterSpacing: 1, textTransform: "uppercase" }}>Round {ri + 1}</div>
                      {round.map((match, mi) => {
                        const key = `${ri}-${mi}`, fw = fixWinner(key, match);
                        return (
                          <div key={mi} className="fixture-card">
                            <div className="fix-team" style={{ color: fw === match[0] ? C.accent : C.text }}>{match[0]}</div>
                            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                              <input className="fix-score-input" type="number" min="0" value={fixScores[key]?.a ?? ""} onChange={e => setFixScores(s => ({ ...s, [key]: { ...s[key], a: e.target.value } }))} />
                              <span style={{ color: C.textDim, fontWeight: 700 }}>–</span>
                              <input className="fix-score-input" type="number" min="0" value={fixScores[key]?.b ?? ""} onChange={e => setFixScores(s => ({ ...s, [key]: { ...s[key], b: e.target.value } }))} />
                            </div>
                            <div className="fix-team" style={{ textAlign: "right", color: fw === match[1] ? C.accent : C.text }}>{match[1]}</div>
                            {fw && <div className="fix-winner-badge">{fw === "draw" ? "Draw" : `W: ${fw.slice(0, 10)}`}</div>}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                  <button className="btn btn-danger btn-sm" onClick={() => { setTournStarted(false); setTournTeams([]); }}>Reset Tournament</button>
                </div>
              </>
            )}
          </>
        )}

        {/* ── STATS ── */}
        {view === "stats" && <StatsView history={history} players={players} />}

        {/* ── HISTORY ── */}
        {view === "history" && (
          history.length === 0
            ? <div className="empty"><div className="empty-icon">📋</div><div className="empty-text">No matches yet</div><div className="empty-sub">Completed matches appear here</div></div>
            : history.map((m, i) => (
              <div key={i} className="match-card">
                <div className="mc-teams">
                  <div className="mc-team">
                    <div className="mc-name" style={{ color: C.sideA }}>{m.teamA.name}</div>
                    <div className="mc-players">{m.teamA.players.join(" · ")}</div>
                    <div className="mc-result-pips">
                      <div className={`result-pip ${m.winner === "A" ? "win" : "loss"}`} />
                    </div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, minWidth: 32 }}>
                    <div style={{ fontSize: 10, color: C.textDim, fontWeight: 700, letterSpacing: 1 }}>VS</div>
                    <div className="mc-badge type">{m.type === "doubles" ? "2v2" : "1v1"}</div>
                  </div>
                  <div className="mc-team mc-team-b">
                    <div className="mc-name" style={{ color: C.sideB }}>{m.teamB.name}</div>
                    <div className="mc-players">{m.teamB.players.join(" · ")}</div>
                    <div className="mc-result-pips right">
                      <div className={`result-pip ${m.winner === "B" ? "win" : "loss"}`} />
                    </div>
                  </div>
                </div>
                <div className="mc-sets">
                  <span style={{ fontSize: 10, color: C.textDim, fontWeight: 700, marginRight: 4, letterSpacing: .5, textTransform: "uppercase" }}>Sets</span>
                  {m.sets.map((s, j) => (
                    <div key={j} className="set-pill">
                      <span style={{ color: s.winner === "A" ? C.sideA : C.textDim, fontWeight: s.winner === "A" ? 700 : 400 }}>{s.scoreA}</span>
                      <span style={{ color: C.textDim }}>–</span>
                      <span style={{ color: s.winner === "B" ? C.sideB : C.textDim, fontWeight: s.winner === "B" ? 700 : 400 }}>{s.scoreB}</span>
                    </div>
                  ))}
                  <div style={{ flex: 1 }} />
                  <div className="mc-badge win">🏆 {m.winner === "A" ? m.teamA.name : m.teamB.name}</div>
                </div>
                {m.date && <div style={{ fontSize: 10, color: C.textDim, marginTop: 6 }}>{new Date(m.date).toLocaleString()}</div>}
              </div>
            ))
        )}
      </div>

      {/* Bottom nav */}
      <div className="bot-nav">
        {navItems.map(n => (
          <button key={n.id} className={`bot-nav-btn ${view === n.id ? "active" : ""}`} onClick={() => setView(n.id)}>
            <span className="bot-nav-icon">{n.icon}</span>{n.label}
          </button>
        ))}
      </div>

      {/* Winner modal */}
      {winner && (
        <div className="overlay">
          <div className="winner-modal">
            <div className="trophy-big">🏆</div>
            <div className="winner-label">Match Winner</div>
            <div className="winner-name" style={{ color: winner === "A" ? C.sideA : C.sideB }}>
              {(winner === "A" ? teamA : teamB).name}
            </div>
            <div style={{ color: C.textMid, fontSize: 13, marginBottom: 6 }}>{(winner === "A" ? teamA : teamB).players.join(" & ")}</div>
            <div className="final-sets">
              {sets.map((s, i) => (
                <div key={i} className="set-badge">
                  <span className="set-num">S{i + 1}</span>
                  <span style={{ color: s.winner === "A" ? C.sideA : C.textDim, fontWeight: s.winner === "A" ? 700 : 400 }}>{s.scoreA}</span>
                  <span style={{ color: C.textDim }}>–</span>
                  <span style={{ color: s.winner === "B" ? C.sideB : C.textDim, fontWeight: s.winner === "B" ? 700 : 400 }}>{s.scoreB}</span>
                </div>
              ))}
            </div>
            <div className="modal-btns">
              {isReferee && <>
                <button className="btn btn-ghost" onClick={() => { setWinner(null); resetMatch(); }}>Play Again</button>
                <button className="btn btn-accent" onClick={() => { setWinner(null); resetMatch(); setView("setup"); setSetupStep(0); }}>New Match</button>
              </>}
              {!isReferee && <button className="btn btn-ghost" onClick={() => setWinner(null)}>Close</button>}
            </div>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </>
  );
}
