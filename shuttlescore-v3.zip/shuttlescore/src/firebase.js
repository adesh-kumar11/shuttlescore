import { initializeApp } from "firebase/app";
import { getFirestore, doc, onSnapshot, setDoc, getDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAh-O7VYp3difqPM7Zu_bhTvbfoURSdTNc",
  authDomain: "shuttlescore-98ba5.firebaseapp.com",
  projectId: "shuttlescore-98ba5",
  storageBucket: "shuttlescore-98ba5.firebasestorage.app",
  messagingSenderId: "719237539335",
  appId: "1:719237539335:web:2b7a6369a4854d79f52ca2"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

const grp = (room) => `groups/${room}`;
export const liveMatchRef  = (r) => doc(db, grp(r), "live_match");
export const playersRef    = (r) => doc(db, grp(r), "players");
export const teamsRef      = (r) => doc(db, grp(r), "teams");
export const historyRef    = (r) => doc(db, grp(r), "match_history");
export const metaRef       = (r) => doc(db, grp(r), "meta");
export const tournRef      = (r) => doc(db, grp(r), "tournament");

const set$ = async (ref, data) => { try { await setDoc(ref, { ...data, _t: Date.now() }); } catch(e) { console.error(e); } };
export const saveRoomMeta    = (r,d) => set$(metaRef(r), d);
export const getRoomMeta     = async (r) => { try { const s=await getDoc(metaRef(r)); return s.exists()?s.data():null; } catch { return null; } };
export const saveLiveMatch   = (r,d) => set$(liveMatchRef(r), d);
export const savePlayers     = (r,d) => set$(playersRef(r), { players: d });
export const saveTeams       = (r,d) => set$(teamsRef(r), { teams: d });
export const saveHistory     = (r,d) => set$(historyRef(r), { history: d });
export const saveTournament  = (r,d) => set$(tournRef(r), d);

export const subscribeLiveMatch = (r,cb) => onSnapshot(liveMatchRef(r), s => s.exists() && cb(s.data()));
export const subscribePlayers   = (r,cb) => onSnapshot(playersRef(r),   s => s.exists() && cb(s.data().players||[]));
export const subscribeTeams     = (r,cb) => onSnapshot(teamsRef(r),     s => s.exists() && cb(s.data().teams||[]));
export const subscribeHistory   = (r,cb) => onSnapshot(historyRef(r),   s => s.exists() && cb(s.data().history||[]));
export const subscribeTournament= (r,cb) => onSnapshot(tournRef(r),     s => s.exists() && cb(s.data()));
