import { useState, useEffect, useCallback, useRef } from "react";
import {
  saveLiveMatch, savePlayers, saveTeams, saveHistory, saveTournament, saveRoomMeta, getRoomMeta,
  subscribeLiveMatch, subscribePlayers, subscribeTeams, subscribeHistory, subscribeTournament
} from "./firebase";

// ─── GAME LOGIC ───────────────────────────────────────────────────────────────
const WIN_BY=2, MAX_PTS=21, DEUCE_CAP=30;
const gw=(a,b)=>((a>=MAX_PTS||a===DEUCE_CAP)&&a-b>=WIN_BY)?"A":((b>=MAX_PTS||b===DEUCE_CAP)&&b-a>=WIN_BY)?"B":null;
const mw=(sets,n)=>sets.filter(s=>s.winner==="A").length>=n?"A":sets.filter(s=>s.winner==="B").length>=n?"B":null;
const shuffle=a=>{const r=[...a];for(let i=r.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[r[i],r[j]]=[r[j],r[i]];}return r;};

// ─── TOURNAMENT ENGINE ────────────────────────────────────────────────────────
// Returns { type, rounds } where rounds = array of rounds, each round = array of matches
// match = { id, teamA, teamB, scoreA, scoreB, winner, status, isBye }
function buildTournament(teams) {
  const n = teams.length;
  if (n < 2) return null;

  // Round Robin for ≤5 teams
  if (n <= 5) {
    const t = [...teams]; if (t.length%2) t.push(null);
    const numRounds = t.length-1, half = t.length/2;
    const rounds = [];
    for (let r=0; r<numRounds; r++) {
      const matches = [];
      for (let i=0; i<half; i++) {
        const a=t[i], b=t[t.length-1-i];
        if (a&&b) matches.push(mkMatch(r*100+i, a, b));
        else if (a||b) matches.push(mkBye(r*100+i, a||b));
      }
      rounds.push({ name:`Round ${r+1}`, matches });
      t.splice(1,0,t.pop());
    }
    return { type:"round-robin", rounds };
  }

  // Single elimination for 6+
  // Fill to next power of 2
  const pow2 = Math.pow(2, Math.ceil(Math.log2(n)));
  const seeded = [...shuffle(teams)];
  while (seeded.length < pow2) seeded.push(null); // nulls = byes

  // Round 1
  const r1matches = [];
  for (let i=0; i<seeded.length; i+=2) {
    const a=seeded[i], b=seeded[i+1];
    if (!b) r1matches.push(mkBye(i/2, a)); // auto advance
    else r1matches.push(mkMatch(i/2, a, b));
  }
  const rounds = [];
  const roundNames = ["Round of "+pow2, "Quarter-Finals","Semi-Finals","Final","Grand Final"];
  let ri = 0;
  let cur = r1matches;
  while (cur.length >= 1) {
    const rname = cur.length===1 ? "Final" : cur.length===2 ? "Semi-Finals" : cur.length===4 ? "Quarter-Finals" : `Round of ${cur.length*2}`;
    rounds.push({ name: rname, matches: cur });
    if (cur.length===1) break;
    // Next round: placeholders
    const next = [];
    for (let i=0; i<cur.length; i+=2) {
      next.push(mkMatch(ri*100+i/2, "TBD", "TBD"));
    }
    cur = next; ri++;
  }
  return { type:"knockout", rounds };
}

function mkMatch(id, a, b) { return { id:`m${id}`, teamA:a, teamB:b, scoreA:null, scoreB:null, winner:null, status:"pending", isBye:false }; }
function mkBye(id, team)   { return { id:`b${id}`, teamA:team, teamB:null, scoreA:null, scoreB:null, winner:team, status:"bye", isBye:true }; }

function propagateKnockout(rounds) {
  // After each match result, advance winner to next round
  const r = rounds.map(rnd=>({...rnd, matches:[...rnd.matches.map(m=>({...m}))]}));
  for (let ri=0; ri<r.length-1; ri++) {
    const cur=r[ri].matches, next=r[ri+1].matches;
    for (let mi=0; mi<cur.length; mi+=2) {
      const m1=cur[mi], m2=cur[mi+1]||{winner:null};
      const slot = next[Math.floor(mi/2)];
      if (!slot) continue;
      slot.teamA = m1.winner||"TBD";
      slot.teamB = m2.winner||"TBD";
      if (slot.teamA==="TBD"||slot.teamB==="TBD") { slot.winner=null; slot.status="pending"; slot.scoreA=null; slot.scoreB=null; }
    }
  }
  return r;
}

// Stats
function computeStats(history, players) {
  const pS={}, tS={};
  players.forEach(p=>{pS[p]={wins:0,losses:0,matches:0,setsWon:0,pointsWon:0,pointsLost:0};});
  history.forEach(m=>{
    const kA=m.teamA.name,kB=m.teamB.name;
    if(!tS[kA])tS[kA]={wins:0,losses:0,setsWon:0,pointsWon:0,pointsLost:0,players:m.teamA.players};
    if(!tS[kB])tS[kB]={wins:0,losses:0,setsWon:0,pointsWon:0,pointsLost:0,players:m.teamB.players};
    const aw=m.winner==="A";
    if(aw){tS[kA].wins++;tS[kB].losses++;}else{tS[kB].wins++;tS[kA].losses++;}
    m.sets.forEach(s=>{
      tS[kA].setsWon+=s.winner==="A"?1:0;tS[kA].pointsWon+=s.scoreA;tS[kA].pointsLost+=s.scoreB;
      tS[kB].setsWon+=s.winner==="B"?1:0;tS[kB].pointsWon+=s.scoreB;tS[kB].pointsLost+=s.scoreA;
    });
    [...m.teamA.players,...m.teamB.players].forEach(p=>{
      if(!pS[p])pS[p]={wins:0,losses:0,matches:0,setsWon:0,pointsWon:0,pointsLost:0};
      pS[p].matches++;
    });
    const sides=[{pl:m.teamA.players,won:aw},{pl:m.teamB.players,won:!aw}];
    sides.forEach(({pl,won})=>pl.forEach(p=>{
      if(!pS[p])pS[p]={wins:0,losses:0,matches:0,setsWon:0,pointsWon:0,pointsLost:0};
      if(won)pS[p].wins++;else pS[p].losses++;
    }));
  });
  return {pS,tS};
}

// ─── TOKENS ──────────────────────────────────────────────────────────────────
const C={
  bg:"#060d14",surf:"#0d1b2a",card:"#112035",cardH:"#162845",
  bdr:"#1e3a52",bdrBr:"#2a5278",
  sA:"#ff4d6d",sAd:"#ff4d6d18",
  sB:"#38b6ff",sBd:"#38b6ff18",
  gr:"#1db954",grd:"#1db95418",grDim:"#0d5229",
  net:"#e8f4f8",acc:"#ffe566",accd:"#ffe56618",
  txt:"#e8f5ff",txtM:"#8db4cc",txtD:"#3d6880",
  win:"#22c55e",winD:"#22c55e18",
  loss:"#ef4444",lossD:"#ef444418",
  live:"#ff4444",
  orange:"#ff8c42",purple:"#b47dff",
};

const css=`
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html{font-size:15px}
body{background:${C.bg};color:${C.txt};font-family:'DM Sans',sans-serif;min-height:100dvh;overflow-x:hidden}
.app{max-width:480px;margin:0 auto;padding:10px 11px 88px}

/* NAV */
.bot-nav{position:fixed;bottom:0;left:0;right:0;background:${C.surf};border-top:1px solid ${C.bdr};display:flex;z-index:50;padding-bottom:env(safe-area-inset-bottom);max-width:480px;margin:0 auto;left:50%;transform:translateX(-50%)}
.nbn{flex:1;padding:9px 2px 7px;border:none;background:transparent;color:${C.txtD};cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:2px;font-family:'DM Sans',sans-serif;font-size:9px;font-weight:700;letter-spacing:.3px;transition:color .2s}
.nbn.on{color:${C.gr}}
.ni{font-size:19px;line-height:1}

/* HDR */
.hdr{display:flex;align-items:center;gap:8px;margin-bottom:14px;padding-top:env(safe-area-inset-top)}
.lbox{width:34px;height:34px;background:${C.gr};border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.ltxt{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;letter-spacing:-.5px;line-height:1.1}
.lsub{font-size:10px;color:${C.txtD};font-weight:600;letter-spacing:.8px;text-transform:uppercase}
.hr{margin-left:auto;display:flex;align-items:center;gap:5px;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end}
.room-chip{display:flex;align-items:center;gap:4px;background:${C.grd};border:1px solid ${C.gr}44;padding:3px 9px;border-radius:20px;font-size:10px;font-weight:700;color:${C.gr};max-width:110px}
.room-chip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sdot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.sdot.ok{background:${C.win}}.sdot.err{background:${C.loss}}.sdot.spin{background:${C.acc};animation:pulse 1s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
.sync-pill{display:flex;align-items:center;gap:4px;font-size:9px;color:${C.txtD}}

/* CARDS */
.card{background:${C.card};border-radius:14px;border:1px solid ${C.bdr}}
.p14{padding:14px}.p16{padding:16px}
.card+.card{margin-top:9px}
.ey{font-size:10px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;color:${C.txtD};margin-bottom:9px}

/* SCOREBOARD */
.sb{background:linear-gradient(150deg,${C.card} 0%,${C.surf} 100%);border-radius:14px;border:1px solid ${C.bdr};padding:12px;margin-bottom:10px}
.sb-top{display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:start;margin-bottom:10px}
.sbt{display:flex;flex-direction:column;gap:2px}
.sbt-r{align-items:flex-end;text-align:right}
.sbn{font-family:'Syne',sans-serif;font-size:15px;font-weight:800;letter-spacing:-.3px;line-height:1.1}
.sbp{font-size:10px;color:${C.txtM};line-height:1.4;margin-top:2px}
.pips{display:flex;gap:3px;margin-top:5px}
.sbt-r .pips{justify-content:flex-end}
.pip{width:11px;height:11px;border-radius:50%;border:1.5px solid ${C.bdr};transition:all .3s}
.pip.wa{background:${C.sA};border-color:${C.sA};box-shadow:0 0 6px ${C.sA}88}
.pip.wb{background:${C.sB};border-color:${C.sB};box-shadow:0 0 6px ${C.sB}88}
.sb-mid{display:flex;flex-direction:column;align-items:center;gap:2px;padding-top:2px}
.sb-ml{font-size:9px;font-weight:700;color:${C.txtD};letter-spacing:.8px}
.sb-sc{display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:6px}
.scn{font-family:'Syne',sans-serif;font-size:86px;font-weight:800;line-height:.9;letter-spacing:-5px}
.scn.a{color:${C.sA};text-shadow:0 0 50px ${C.sA}44}
.scn.b{color:${C.sB};text-shadow:0 0 50px ${C.sB}44}
.sc-sep{display:flex;flex-direction:column;align-items:center;gap:5px}
.sorb{width:9px;height:9px;border-radius:50%;background:${C.acc};animation:sg 1.2s ease-in-out infinite}
@keyframes sg{0%,100%{box-shadow:0 0 4px ${C.acc}}50%{box-shadow:0 0 14px ${C.acc};opacity:.6}}
.sep-l{width:2px;height:36px;background:${C.bdr};border-radius:1px}
.set-row{display:flex;justify-content:center;gap:5px;flex-wrap:wrap;margin-top:6px}
.spill{display:flex;align-items:center;gap:3px;background:${C.surf};border:1px solid ${C.bdr};border-radius:16px;padding:3px 8px;font-family:'JetBrains Mono',monospace;font-size:11px}
.sn{font-size:9px;color:${C.txtD};margin-right:1px}

/* COURT */
.court-wrap{position:relative;border-radius:14px;overflow:hidden;margin-bottom:10px;user-select:none;touch-action:manipulation}
.ctap{position:absolute;top:0;height:100%;transition:background .1s}
.ctap:active{background:rgba(255,255,255,.07)}
.rpl{position:absolute;border-radius:50%;pointer-events:none;transform:translate(-50%,-50%);animation:rOut .5s ease-out forwards}
@keyframes rOut{0%{width:0;height:0;opacity:.8}100%{width:120px;height:120px;opacity:0}}
.ptt{position:absolute;font-family:'Syne',sans-serif;font-size:24px;font-weight:800;pointer-events:none;animation:ptU .6s ease-out forwards}
@keyframes ptU{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(-40px)}}

/* BTNS */
.btn{padding:9px 13px;border:none;border-radius:10px;cursor:pointer;font-family:'DM Sans',sans-serif;font-weight:700;font-size:13px;transition:all .15s;display:inline-flex;align-items:center;justify-content:center;gap:5px;white-space:nowrap;line-height:1}
.bg{background:${C.gr};color:#000}.bg:hover{filter:brightness(1.08)}
.by{background:${C.acc};color:#000}.by:hover{filter:brightness(1.08)}
.bo{background:${C.card};color:${C.txt};border:1px solid ${C.bdr}}.bo:hover{border-color:${C.bdrBr}}
.br{background:${C.lossD};color:${C.loss};border:1px solid ${C.loss}33}
.bpu{background:${C.purple}22;color:${C.purple};border:1px solid ${C.purple}44}
.bor{background:${C.orange}22;color:${C.orange};border:1px solid ${C.orange}44}
.bsm{padding:5px 10px;font-size:12px;border-radius:8px}
.bxs{padding:4px 8px;font-size:11px;border-radius:7px}
.bfull{width:100%}
.btn:disabled{opacity:.35;pointer-events:none}
.ctrl{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}

/* INPUTS */
.inp{background:${C.surf};border:1.5px solid ${C.bdr};color:${C.txt};padding:9px 11px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;outline:none;transition:border .2s;width:100%}
.inp:focus{border-color:${C.gr}}
.inp::placeholder{color:${C.txtD}}
.ir{display:flex;gap:7px;margin-bottom:9px}
.lbl{font-size:11px;font-weight:700;color:${C.txtD};margin-bottom:4px}

/* CHIPS */
.chip{display:inline-flex;align-items:center;gap:4px;background:${C.surf};border:1px solid ${C.bdr};padding:3px 9px;border-radius:20px;font-size:12px;font-weight:600;margin:3px}
.cx{background:none;border:none;color:${C.txtD};cursor:pointer;font-size:14px;line-height:1;padding:0}.cx:hover{color:${C.loss}}

/* CFG */
.cfgr{display:flex;gap:7px;margin-bottom:10px}
.cfgo{flex:1;padding:9px 5px;border:1.5px solid ${C.bdr};border-radius:10px;background:transparent;color:${C.txtM};cursor:pointer;font-family:'DM Sans',sans-serif;font-weight:700;font-size:12px;transition:all .18s;text-align:center;line-height:1.4}
.cfgo.on{border-color:${C.gr};background:${C.grd};color:${C.gr}}

/* TABS */
.tabs{display:flex;gap:6px;margin-bottom:13px;flex-wrap:wrap}
.tab{padding:6px 12px;border:1.5px solid ${C.bdr};border-radius:20px;cursor:pointer;font-size:11px;font-weight:700;font-family:'DM Sans',sans-serif;transition:all .18s;background:transparent;color:${C.txtM}}
.tab.on{background:${C.gr};color:#000;border-color:${C.gr}}

/* MATCH HISTORY */
.mc{background:${C.card};border:1px solid ${C.bdr};border-radius:13px;padding:12px;margin-bottom:8px}
.mc-top{display:flex;align-items:flex-start;justify-content:space-between;gap:7px;margin-bottom:7px}
.mcs{flex:1}.mcs-r{text-align:right}
.mcn{font-family:'Syne',sans-serif;font-size:13px;font-weight:800}
.mcp{font-size:10px;color:${C.txtM};margin-top:1px;line-height:1.4}
.mcpi{display:flex;gap:3px;margin-top:4px}
.mcpi-r{justify-content:flex-end}
.rpip{width:9px;height:9px;border-radius:50%;background:${C.bdr}}
.rpip.w{background:${C.win};box-shadow:0 0 5px ${C.win}55}
.rpip.l{background:${C.loss};box-shadow:0 0 4px ${C.loss}33}
.mc-sets{display:flex;gap:5px;align-items:center;flex-wrap:wrap;padding-top:7px;border-top:1px solid ${C.bdr}}
.mcb{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:9px;font-weight:700}
.mcb.w{background:${C.winD};color:${C.win};border:1px solid ${C.win}33}
.mcb.t{background:${C.accd};color:${C.acc};border:1px solid ${C.acc}33}

/* STATS */
.sg{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:7px}
.sb2{background:${C.surf};border-radius:10px;padding:9px 5px;text-align:center}
.sv{font-family:'Syne',sans-serif;font-size:21px;font-weight:800;line-height:1}
.sl{font-size:9px;color:${C.txtD};font-weight:700;margin-top:2px;letter-spacing:.5px;text-transform:uppercase}
.wrb{height:4px;background:${C.bdr};border-radius:2px;overflow:hidden;margin:4px 0}
.wrf{height:100%;background:linear-gradient(90deg,${C.gr},${C.acc});border-radius:2px}
.psc{background:${C.card};border:1px solid ${C.bdr};border-radius:13px;padding:12px;margin-bottom:7px}
.psc-top{display:flex;align-items:center;gap:8px;margin-bottom:10px}
.ava{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-weight:800;font-size:14px;flex-shrink:0}

/* ── TOURNAMENT ── */
/* Bracket */
.bracket{overflow-x:auto;padding-bottom:8px}
.bracket-rounds{display:flex;gap:10px;min-width:max-content;padding:4px}
.b-round{display:flex;flex-direction:column;gap:0;min-width:150px}
.b-round-name{font-size:9px;font-weight:700;color:${C.txtD};letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;text-align:center}
.b-matches{display:flex;flex-direction:column;justify-content:space-around;flex:1;gap:8px}
.b-match{background:${C.surf};border:1px solid ${C.bdr};border-radius:10px;overflow:hidden;transition:border-color .2s}
.b-match.done{border-color:${C.gr}44}
.b-match.live-m{border-color:${C.acc};box-shadow:0 0 8px ${C.acc}33}
.b-match.bye{opacity:.5}
.b-slot{display:flex;align-items:center;gap:6px;padding:6px 8px;font-size:12px;font-weight:600;min-height:30px}
.b-slot+.b-slot{border-top:1px solid ${C.bdr}}
.b-slot.winner{background:${C.grd};color:${C.gr}}
.b-slot.loser{color:${C.txtD}}
.b-seed{font-size:9px;color:${C.txtD};font-family:'JetBrains Mono',monospace;min-width:12px}
.b-score{margin-left:auto;font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700}
.b-actions{display:flex;gap:4px;padding:5px 7px;border-top:1px solid ${C.bdr};background:${C.card}}

/* Fixture card (list view) */
.fcard{background:${C.card};border:1px solid ${C.bdr};border-radius:12px;margin-bottom:7px;overflow:hidden}
.fcard-head{display:flex;align-items:center;gap:6px;padding:10px 12px}
.ft{flex:1;font-weight:700;font-size:12px;line-height:1.3;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ft-r{text-align:right}
.f-score{display:flex;align-items:center;gap:5px;flex-shrink:0}
.finp{width:34px;text-align:center;background:${C.surf};border:1.5px solid ${C.bdr};color:${C.txt};padding:4px;border-radius:6px;font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:600}
.finp:focus{border-color:${C.gr};outline:none}
.fcard-foot{display:flex;gap:5px;padding:6px 10px;border-top:1px solid ${C.bdr};background:${C.surf};flex-wrap:wrap}
.bye-card{background:${C.card};border:1px solid ${C.bdr}33;border-radius:12px;padding:8px 12px;margin-bottom:7px;display:flex;align-items:center;gap:8px;opacity:.6}

/* Standings */
.std{width:100%;border-collapse:collapse;font-size:11px}
.std th{text-align:left;padding:5px 7px;color:${C.txtD};font-weight:700;font-size:9px;letter-spacing:.8px;text-transform:uppercase;border-bottom:1px solid ${C.bdr}}
.std td{padding:6px 7px;border-bottom:1px solid ${C.bdr}33}
.std tr:first-child td{color:${C.acc}}
.pts{font-family:'JetBrains Mono',monospace;font-weight:700;color:${C.gr}}

/* Registry */
.reg-card{background:${C.card};border:1px solid ${C.bdr};border-radius:12px;padding:11px 13px;margin-bottom:7px;display:flex;align-items:center;gap:9px}
.reg-card.dragging{border-color:${C.gr};background:${C.grd}}
.reg-num{font-family:'Syne',sans-serif;font-size:16px;font-weight:800;color:${C.acc};min-width:22px}
.reg-name{flex:1;font-weight:700;font-size:13px}
.reg-sub{font-size:11px;color:${C.txtM};margin-top:1px}

/* Swap modal */
.modal{position:fixed;inset:0;background:#000d;display:flex;align-items:flex-end;justify-content:center;z-index:300;animation:fIn .2s}
@keyframes fIn{from{opacity:0}to{opacity:1}}
.modal-box{background:${C.card};border-radius:20px 20px 0 0;padding:20px 16px 32px;width:100%;max-width:480px;border-top:1px solid ${C.bdr}}
.modal-title{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;margin-bottom:14px}
.sel-item{display:flex;align-items:center;gap:8px;padding:10px 12px;background:${C.surf};border-radius:10px;margin-bottom:6px;cursor:pointer;border:1.5px solid transparent;transition:all .15s;font-weight:600;font-size:13px}
.sel-item:hover,.sel-item.picked{border-color:${C.gr};background:${C.grd};color:${C.gr}}

/* TOAST */
.toast{position:fixed;top:54px;left:50%;transform:translateX(-50%);background:${C.card};border:1px solid ${C.gr};color:${C.gr};padding:7px 16px;border-radius:20px;font-weight:700;font-size:12px;z-index:400;animation:tIn .25s ease-out;white-space:nowrap;pointer-events:none}
@keyframes tIn{from{opacity:0;transform:translateX(-50%) translateY(-10px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}

/* WINNER */
.ov{position:fixed;inset:0;background:#000d;display:flex;align-items:center;justify-content:center;z-index:300;animation:fIn .2s}
.wm{background:${C.card};border-radius:20px;padding:26px 20px;text-align:center;border:1px solid ${C.gr}44;max-width:310px;width:92%;box-shadow:0 0 60px ${C.gr}18}
.tr{font-size:52px;margin-bottom:4px;animation:bIn .5s ease-out}
@keyframes bIn{0%{transform:scale(0)}70%{transform:scale(1.1)}100%{transform:scale(1)}}

/* LIVE */
.live-bar{background:${C.accd};border:1px solid ${C.acc}44;border-radius:11px;padding:8px 12px;margin-bottom:9px;display:flex;align-items:center;gap:7px;font-size:12px;font-weight:700;color:${C.acc}}
.ldot{width:7px;height:7px;border-radius:50%;background:${C.live};animation:pulse 1s infinite;flex-shrink:0}

/* EMPTY */
.empty{text-align:center;padding:30px 16px;color:${C.txtD}}
.ei{font-size:36px;margin-bottom:7px;opacity:.5}
.et{font-size:13px;font-weight:600}.es{font-size:11px;margin-top:3px}
.div{height:1px;background:${C.bdr};margin:12px 0}

/* LOBBY */
.lobby{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:90dvh;padding:20px;text-align:center}
.llogo{font-size:52px;margin-bottom:10px}
.ltitle{font-family:'Syne',sans-serif;font-size:28px;font-weight:800;letter-spacing:-1px;margin-bottom:3px}
.lsub{font-size:13px;color:${C.txtM};margin-bottom:24px}
.rcard{background:${C.card};border:1px solid ${C.bdr};border-radius:14px;padding:16px;width:100%;max-width:320px;margin-bottom:10px;text-align:left}
.rcardT{font-family:'Syne',sans-serif;font-size:14px;font-weight:800;margin-bottom:11px}
.locked{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(6,13,20,.65);border-radius:14px;font-size:26px}
`;

// ─── COURT ───────────────────────────────────────────────────────────────────
function Court({onScore,serving,disabled}){
  const [fx,setFx]=useState([]);const nid=useRef(0);
  const tap=useCallback((side,e)=>{
    if(disabled)return;
    const r=e.currentTarget.closest(".court-wrap").getBoundingClientRect();
    const x=e.clientX-r.left,y=e.clientY-r.top,id=nid.current++;
    setFx(f=>[...f,{id,x,y,side}]);setTimeout(()=>setFx(f=>f.filter(i=>i.id!==id)),600);
    onScore(side);
  },[onScore,disabled]);
  return (
    <div className="court-wrap" style={{opacity:disabled?.5:1,pointerEvents:disabled?"none":"auto"}}>
      <svg viewBox="0 0 540 300" style={{display:"block",width:"100%"}}>
        <defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0a5c2e"/><stop offset="100%" stopColor="#073d1e"/></linearGradient></defs>
        <rect width="540" height="300" fill="url(#cg)"/>
        <rect x="24" y="16" width="492" height="268" fill="none" stroke={C.gr} strokeWidth="2" opacity=".9"/>
        <rect x="56" y="16" width="428" height="268" fill="none" stroke={C.grDim} strokeWidth="1.2" opacity=".6"/>
        <line x1="24" y1="40" x2="516" y2="40" stroke={C.grDim} strokeWidth="1" opacity=".4" strokeDasharray="4,4"/>
        <line x1="24" y1="260" x2="516" y2="260" stroke={C.grDim} strokeWidth="1" opacity=".4" strokeDasharray="4,4"/>
        <line x1="24" y1="96" x2="516" y2="96" stroke={C.gr} strokeWidth="1.2" opacity=".6"/>
        <line x1="24" y1="204" x2="516" y2="204" stroke={C.gr} strokeWidth="1.2" opacity=".6"/>
        <line x1="270" y1="96" x2="270" y2="204" stroke={C.gr} strokeWidth="1.2" opacity=".5"/>
        <rect x="265" y="10" width="10" height="280" fill="rgba(255,255,255,.05)" rx="2"/>
        <line x1="270" y1="10" x2="270" y2="290" stroke={C.net} strokeWidth="2.5" opacity=".85"/>
        <circle cx="270" cy="10" r="4" fill={C.net} opacity=".5"/><circle cx="270" cy="290" r="4" fill={C.net} opacity=".5"/>
        {serving==="A"&&<circle cx="142" cy="150" r="8" fill={C.acc} opacity=".9"><animate attributeName="r" values="8;10;8" dur="1.1s" repeatCount="indefinite"/><animate attributeName="opacity" values=".9;.5;.9" dur="1.1s" repeatCount="indefinite"/></circle>}
        {serving==="B"&&<circle cx="398" cy="150" r="8" fill={C.acc} opacity=".9"><animate attributeName="r" values="8;10;8" dur="1.1s" repeatCount="indefinite"/><animate attributeName="opacity" values=".9;.5;.9" dur="1.1s" repeatCount="indefinite"/></circle>}
        <text x="142" y="150" textAnchor="middle" dominantBaseline="middle" fill={C.sA} opacity=".14" style={{fontSize:36,fontFamily:"Syne,sans-serif",fontWeight:800}}>TAP</text>
        <text x="398" y="150" textAnchor="middle" dominantBaseline="middle" fill={C.sB} opacity=".14" style={{fontSize:36,fontFamily:"Syne,sans-serif",fontWeight:800}}>TAP</text>
      </svg>
      <div className="ctap" style={{left:0,width:"50%"}} onClick={e=>tap("A",e)}/>
      <div className="ctap" style={{right:0,width:"50%"}} onClick={e=>tap("B",e)}/>
      {fx.map(f=>(
        <div key={f.id}>
          <div className="rpl" style={{left:f.x,top:f.y,background:f.side==="A"?C.sA:C.sB}}/>
          <div className="ptt" style={{left:f.x-14,top:f.y-14,color:f.side==="A"?C.sA:C.sB}}>+1</div>
        </div>
      ))}
    </div>
  );
}

// ─── SCOREBOARD ──────────────────────────────────────────────────────────────
function Scoreboard({tA,tB,sA,sB,sets,serving,setsToWin}){
  const wA=sets.filter(s=>s.winner==="A").length, wB=sets.filter(s=>s.winner==="B").length;
  return (
    <div className="sb">
      <div className="sb-top">
        <div className="sbt">
          <div className="sbn" style={{color:C.sA}}>{tA.name||"Team A"}</div>
          <div className="sbp">{tA.players.join(" / ")}</div>
          <div className="pips">{Array.from({length:setsToWin}).map((_,i)=><div key={i} className={`pip ${wA>i?"wa":""}`}/>)}</div>
        </div>
        <div className="sb-mid">
          <div className="sb-ml">{tA.type==="doubles"?"DOUBLES":"SINGLES"}</div>
          <div style={{fontSize:9,color:C.txtD,fontWeight:700}}>SET {sets.length+1}</div>
        </div>
        <div className="sbt sbt-r">
          <div className="sbn" style={{color:C.sB}}>{tB.name||"Team B"}</div>
          <div className="sbp">{tB.players.join(" / ")}</div>
          <div className="pips">{Array.from({length:setsToWin}).map((_,i)=><div key={i} className={`pip ${wB>i?"wb":""}`}/>)}</div>
        </div>
      </div>
      <div className="sb-sc">
        <div className="scn a">{sA}</div>
        <div className="sc-sep">
          {serving==="A"?<div className="sorb"/>:<div style={{width:9,height:9}}/>}
          <div className="sep-l"/>
          {serving==="B"?<div className="sorb"/>:<div style={{width:9,height:9}}/>}
        </div>
        <div className="scn b">{sB}</div>
      </div>
      {sets.length>0&&<div className="set-row">{sets.map((s,i)=>(
        <div key={i} className="spill">
          <span className="sn">S{i+1}</span>
          <span style={{color:s.winner==="A"?C.sA:C.txtD,fontWeight:s.winner==="A"?700:400}}>{s.scoreA}</span>
          <span style={{color:C.txtD}}>–</span>
          <span style={{color:s.winner==="B"?C.sB:C.txtD,fontWeight:s.winner==="B"?700:400}}>{s.scoreB}</span>
        </div>
      ))}</div>}
    </div>
  );
}

// ─── REGISTRY ────────────────────────────────────────────────────────────────
function Registry({players,teams,onSavePlayers,onSaveTeams,isRef}){
  const [tab,setTab]=useState("players");
  const [pInput,setPInput]=useState("");
  const [tName,setTName]=useState("");
  const [tP1,setTP1]=useState("");
  const [tP2,setTP2]=useState("");
  const [editTeamIdx,setEditTeamIdx]=useState(null);
  const [swapModal,setSwapModal]=useState(null); // {teamIdx, memberIdx}
  const [picked,setPicked]=useState(null);

  const addPlayer=()=>{
    const n=pInput.trim(); if(!n||players.includes(n))return;
    onSavePlayers([...players,n]); setPInput("");
  };
  const removePlayer=n=>onSavePlayers(players.filter(p=>p!==n));

  const addTeam=()=>{
    const n=tName.trim(),p1=tP1.trim(),p2=tP2.trim();
    if(!n||!p1)return;
    const members=[p1,p2].filter(Boolean);
    if(editTeamIdx!==null){
      const updated=[...teams]; updated[editTeamIdx]={name:n,members};
      onSaveTeams(updated); setEditTeamIdx(null);
    } else {
      onSaveTeams([...teams,{name:n,members}]);
    }
    setTName("");setTP1("");setTP2("");
  };
  const removeTeam=i=>onSaveTeams(teams.filter((_,idx)=>idx!==i));
  const editTeam=(i)=>{const t=teams[i];setTName(t.name);setTP1(t.members[0]||"");setTP2(t.members[1]||"");setEditTeamIdx(i);};

  const startSwap=(teamIdx,memberIdx)=>{ setSwapModal({teamIdx,memberIdx}); setPicked(null); };
  const doSwap=(newPlayer)=>{
    if(!swapModal)return;
    const updated=teams.map((t,i)=>{
      if(i!==swapModal.teamIdx)return t;
      const members=[...t.members]; members[swapModal.memberIdx]=newPlayer;
      return {...t,members};
    });
    onSaveTeams(updated); setSwapModal(null);
  };

  return (
    <>
      <div className="tabs">
        <button className={`tab ${tab==="players"?"on":""}`} onClick={()=>setTab("players")}>Players ({players.length})</button>
        <button className={`tab ${tab==="teams"?"on":""}`} onClick={()=>setTab("teams")}>Teams ({teams.length})</button>
      </div>

      {tab==="players"&&(
        <div className="card p14">
          <div className="ey">Player Registry</div>
          {isRef&&(
            <div className="ir">
              <input className="inp" value={pInput} onChange={e=>setPInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addPlayer()} placeholder="Player name…"/>
              <button className="btn bg" style={{whiteSpace:"nowrap"}} onClick={addPlayer}>Add</button>
            </div>
          )}
          {players.length===0&&<div className="empty" style={{padding:"16px 0"}}><div className="ei">👤</div><div className="et">No players yet</div></div>}
          {players.map((p,i)=>(
            <div key={p} className="reg-card">
              <div className="reg-num">{i+1}</div>
              <div style={{flex:1}}><div className="reg-name">{p}</div></div>
              {isRef&&<button className="btn br bxs" onClick={()=>removePlayer(p)}>Remove</button>}
            </div>
          ))}
        </div>
      )}

      {tab==="teams"&&(
        <div className="card p14">
          <div className="ey">Team Registry</div>
          {isRef&&(
            <>
              <div className="lbl">Team name</div>
              <input className="inp" value={tName} onChange={e=>setTName(e.target.value)} placeholder="e.g. Smashers" style={{marginBottom:8}}/>
              <div className="lbl">Player 1 (type or pick from list)</div>
              <select className="inp" value={tP1} onChange={e=>setTP1(e.target.value)} style={{marginBottom:8}}>
                <option value="">— select —</option>
                {players.map(p=><option key={p} value={p}>{p}</option>)}
              </select>
              <div className="lbl">Player 2 (optional for singles)</div>
              <select className="inp" value={tP2} onChange={e=>setTP2(e.target.value)} style={{marginBottom:10}}>
                <option value="">— none (singles) —</option>
                {players.filter(p=>p!==tP1).map(p=><option key={p} value={p}>{p}</option>)}
              </select>
              <button className="btn bg bfull" onClick={addTeam} style={{marginBottom:12}}>
                {editTeamIdx!==null?"Update Team":"Add Team"}
              </button>
              {editTeamIdx!==null&&<button className="btn bo bfull" style={{marginBottom:12}} onClick={()=>{setEditTeamIdx(null);setTName("");setTP1("");setTP2("");}}>Cancel Edit</button>}
            </>
          )}
          {teams.length===0&&<div className="empty" style={{padding:"16px 0"}}><div className="ei">👥</div><div className="et">No teams yet</div></div>}
          {teams.map((t,i)=>(
            <div key={i} className="reg-card" style={{flexWrap:"wrap",gap:6}}>
              <div className="reg-num">{i+1}</div>
              <div style={{flex:1}}>
                <div className="reg-name">{t.name}</div>
                <div className="reg-sub">{t.members.join(" & ")}</div>
              </div>
              {isRef&&(
                <div style={{display:"flex",gap:5}}>
                  <button className="btn bpu bxs" onClick={()=>startSwap(i,0)}>🔀 P1</button>
                  {t.members.length>1&&<button className="btn bpu bxs" onClick={()=>startSwap(i,1)}>🔀 P2</button>}
                  <button className="btn bo bxs" onClick={()=>editTeam(i)}>✏️</button>
                  <button className="btn br bxs" onClick={()=>removeTeam(i)}>✕</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Swap member modal */}
      {swapModal&&(
        <div className="modal" onClick={()=>setSwapModal(null)}>
          <div className="modal-box" onClick={e=>e.stopPropagation()}>
            <div className="modal-title">Swap {swapModal.memberIdx===0?"Player 1":"Player 2"} in {teams[swapModal.teamIdx]?.name}</div>
            <div style={{fontSize:12,color:C.txtD,marginBottom:12}}>Current: <strong style={{color:C.txt}}>{teams[swapModal.teamIdx]?.members[swapModal.memberIdx]||"—"}</strong></div>
            {players.map(p=>(
              <div key={p} className={`sel-item ${picked===p?"picked":""}`} onClick={()=>doSwap(p)}>{p}</div>
            ))}
            <button className="btn bo bfull" style={{marginTop:8}} onClick={()=>setSwapModal(null)}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
}

// ─── TOURNAMENT VIEW ──────────────────────────────────────────────────────────
function TournamentView({teams,players,room,isRef,onStartMatch,history,toast$}){
  const [tourn,setTourn]=useState(null); // {type, rounds, started, setsToWin}
  const [tab,setTab]=useState("bracket");
  const [swapModal,setSwapModal]=useState(null); // {roundIdx,matchIdx,slot:"A"|"B"}
  const [byeModal,setByeModal]=useState(null);   // {roundIdx,matchIdx}
  const [setsToWin,setSetsToWin]=useState(2);

  useEffect(()=>{
    if(!room)return;
    return subscribeTournament(room, d=>{
      if(d&&d.rounds) setTourn(d);
    });
  },[room]);

  const save=(t)=>{setTourn(t);saveTournament(room,t);};

  const startTournament=()=>{
    if(teams.length<2){toast$("Need at least 2 teams");return;}
    const teamNames=teams.map(t=>t.name);
    const built=buildTournament(teamNames);
    save({...built, started:true, setsToWin, createdAt:Date.now()});
    setTab("bracket");
  };

  const setMatchScore=(ri,mi,sA,sB)=>{
    if(!tourn)return;
    const r=[...tourn.rounds.map(rnd=>({...rnd,matches:[...rnd.matches.map(m=>({...m}))]}))];
    const match=r[ri].matches[mi];
    match.scoreA=sA; match.scoreB=sB;
    const wScore=parseInt(sA),lScore=parseInt(sB);
    if(!isNaN(wScore)&&!isNaN(lScore)&&(wScore>=21||lScore>=21)){
      match.winner=wScore>lScore?match.teamA:match.teamB;
      match.status="done";
    } else { match.winner=null; match.status="pending"; }
    const propagated = tourn.type==="knockout" ? propagateKnockout(r) : r;
    save({...tourn, rounds:propagated});
  };

  const assignBye=(ri,mi,slot)=>{
    if(!tourn)return;
    const r=tourn.rounds.map(rnd=>({...rnd,matches:[...rnd.matches.map(m=>({...m}))]}));
    const match=r[ri].matches[mi];
    if(slot==="A"){match.teamA=null;match.winner=match.teamB;match.status="bye";}
    else{match.teamB=null;match.winner=match.teamA;match.status="bye";}
    const propagated=tourn.type==="knockout"?propagateKnockout(r):r;
    save({...tourn,rounds:propagated});setByeModal(null);
  };

  const swapTeams=(ri,mi,slot)=>setSwapModal({ri,mi,slot});
  const doSwapTeam=(newTeam)=>{
    if(!swapModal||!tourn)return;
    const {ri,mi,slot}=swapModal;
    const r=tourn.rounds.map(rnd=>({...rnd,matches:[...rnd.matches.map(m=>({...m}))]}));
    if(slot==="A")r[ri].matches[mi].teamA=newTeam;
    else r[ri].matches[mi].teamB=newTeam;
    r[ri].matches[mi].winner=null;r[ri].matches[mi].status="pending";
    const propagated=tourn.type==="knockout"?propagateKnockout(r):r;
    save({...tourn,rounds:propagated});setSwapModal(null);
  };

  const launchMatch=(match)=>{
    const tA=teams.find(t=>t.name===match.teamA)||{name:match.teamA,members:[match.teamA]};
    const tB=teams.find(t=>t.name===match.teamB)||{name:match.teamB,members:[match.teamB]};
    onStartMatch({
      teamA:{name:tA.name,players:tA.members,type:tA.members.length>1?"doubles":"singles"},
      teamB:{name:tB.name,players:tB.members,type:tB.members.length>1?"doubles":"singles"},
      setsToWin:tourn?.setsToWin||2,
      tournMatch:{ri:0,mi:0,match} // reference for saving result back
    });
  };

  const resetTournament=()=>{save(null);setTourn(null);};

  // Round-robin standings
  const rrStandings=()=>{
    if(!tourn)return [];
    const t={};teams.forEach(tm=>{t[tm.name]={w:0,l:0,d:0,pts:0,f:0,a:0};});
    tourn.rounds.forEach(rnd=>rnd.matches.forEach(m=>{
      if(m.status!=="done"||m.isBye)return;
      const a=parseInt(m.scoreA),b=parseInt(m.scoreB);
      if(isNaN(a)||isNaN(b))return;
      if(t[m.teamA])t[m.teamA].f+=a,t[m.teamA].a+=b;
      if(t[m.teamB])t[m.teamB].f+=b,t[m.teamB].a+=a;
      if(a>b){if(t[m.teamA]){t[m.teamA].w++;t[m.teamA].pts+=3;}if(t[m.teamB])t[m.teamB].l++;}
      else if(b>a){if(t[m.teamB]){t[m.teamB].w++;t[m.teamB].pts+=3;}if(t[m.teamA])t[m.teamA].l++;}
      else{if(t[m.teamA]){t[m.teamA].d++;t[m.teamA].pts++;}if(t[m.teamB]){t[m.teamB].d++;t[m.teamB].pts++;}}
    }));
    return Object.entries(t).sort((a,b)=>b[1].pts-a[1].pts||(b[1].f-b[1].a)-(a[1].f-a[1].a));
  };

  if(!tourn||!tourn.started){
    return (
      <div className="card p14">
        <div className="ey">Start Tournament</div>
        <div style={{fontSize:12,color:C.txtM,marginBottom:12}}>
          {teams.length} team{teams.length!==1?"s":""} registered.
          {teams.length<2&&<span style={{color:C.loss}}> Add teams in Registry first.</span>}
          {teams.length>=2&&teams.length<=5&&<span style={{color:C.gr}}> → Round Robin format</span>}
          {teams.length>=6&&<span style={{color:C.gr}}> → Single Elimination bracket</span>}
        </div>
        {teams.map((t,i)=>(
          <div key={i} className="reg-card" style={{marginBottom:5}}>
            <div className="reg-num">{i+1}</div>
            <div style={{flex:1}}><div className="reg-name">{t.name}</div><div className="reg-sub">{t.members.join(" & ")}</div></div>
          </div>
        ))}
        {teams.length>=2&&isRef&&(
          <>
            <div className="div"/>
            <div className="lbl" style={{marginBottom:8}}>Match format</div>
            <div className="cfgr">
              {[1,2,3].map(n=><button key={n} className={`cfgo ${setsToWin===n?"on":""}`} onClick={()=>setSetsToWin(n)}>{n===1?"1 Set":n===2?"Best of 3":"Best of 5"}</button>)}
            </div>
            <button className="btn bg bfull" style={{marginTop:10}} onClick={startTournament}>🏆 Generate {teams.length<=5?"Round Robin":"Bracket"}</button>
          </>
        )}
      </div>
    );
  }

  return (
    <>
      <div className="tabs">
        <button className={`tab ${tab==="bracket"?"on":""}`} onClick={()=>setTab("bracket")}>
          {tourn.type==="knockout"?"🏆 Bracket":"📋 Fixtures"}
        </button>
        {tourn.type==="round-robin"&&<button className={`tab ${tab==="standings"?"on":""}`} onClick={()=>setTab("standings")}>📊 Standings</button>}
      </div>

      {tab==="standings"&&tourn.type==="round-robin"&&(
        <div className="card p14">
          <div className="ey">Standings</div>
          <table className="std">
            <thead><tr><th>#</th><th>Team</th><th>W</th><th>D</th><th>L</th><th>F</th><th>A</th><th>Pts</th></tr></thead>
            <tbody>{rrStandings().map(([name,s],i)=>(
              <tr key={name}>
                <td style={{color:C.txtD,fontWeight:600}}>{i+1}</td>
                <td style={{fontWeight:700,maxWidth:100,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{name}</td>
                <td>{s.w}</td><td>{s.d}</td><td>{s.l}</td><td>{s.f}</td><td>{s.a}</td>
                <td className="pts">{s.pts}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}

      {tab==="bracket"&&tourn.rounds.map((rnd,ri)=>(
        <div key={ri} style={{marginBottom:10}}>
          <div style={{fontSize:10,fontWeight:700,color:C.txtD,letterSpacing:1,textTransform:"uppercase",marginBottom:7,paddingLeft:2}}>{rnd.name}</div>
          {rnd.matches.map((match,mi)=>{
            if(match.isBye||match.status==="bye") return (
              <div key={match.id} className="bye-card">
                <div style={{fontSize:18}}>🎟️</div>
                <div><div style={{fontWeight:700,fontSize:12}}>{match.teamA||match.teamB}</div><div style={{fontSize:10,color:C.txtD}}>BYE — advances automatically</div></div>
              </div>
            );
            const isDone=match.status==="done";
            const isPending=match.teamA==="TBD"||match.teamB==="TBD";
            return (
              <div key={match.id} className={`fcard ${isDone?"done":""}`}>
                <div className="fcard-head">
                  <div className={`ft ${isDone&&match.winner===match.teamA?"":""}` } style={{color:isDone?(match.winner===match.teamA?C.gr:C.txtD):C.txt}}>
                    {match.teamA||"TBD"}
                    {isDone&&match.winner===match.teamA&&<span style={{fontSize:10,marginLeft:4}}>🏆</span>}
                  </div>
                  <div className="f-score">
                    {isRef&&!isPending?(
                      <>
                        <input className="finp" type="number" min="0" value={match.scoreA??""} onChange={e=>setMatchScore(ri,mi,e.target.value,match.scoreB??"")} placeholder="0"/>
                        <span style={{color:C.txtD,fontWeight:700}}>–</span>
                        <input className="finp" type="number" min="0" value={match.scoreB??""} onChange={e=>setMatchScore(ri,mi,match.scoreA??"",e.target.value)} placeholder="0"/>
                      </>
                    ):(
                      <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:13,color:isDone?C.acc:C.txtD,fontWeight:700,padding:"0 4px"}}>
                        {isDone?`${match.scoreA} – ${match.scoreB}`:"vs"}
                      </div>
                    )}
                  </div>
                  <div className={`ft ft-r`} style={{color:isDone?(match.winner===match.teamB?C.gr:C.txtD):C.txt}}>
                    {isDone&&match.winner===match.teamB&&<span style={{fontSize:10,marginRight:4}}>🏆</span>}
                    {match.teamB||"TBD"}
                  </div>
                </div>
                {isRef&&!isPending&&(
                  <div className="fcard-foot">
                    <button className="btn bg bxs" onClick={()=>launchMatch(match)}>▶ Start Match</button>
                    <button className="btn bpu bxs" onClick={()=>swapTeams(ri,mi,"A")}>🔀 {match.teamA?.slice(0,8)||"A"}</button>
                    <button className="btn bpu bxs" onClick={()=>swapTeams(ri,mi,"B")}>🔀 {match.teamB?.slice(0,8)||"B"}</button>
                    <button className="btn bor bxs" onClick={()=>setByeModal({ri,mi})}>BYE</button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}

      {isRef&&(
        <button className="btn br bsm" style={{marginTop:4}} onClick={resetTournament}>Reset Tournament</button>
      )}

      {/* Swap fixture team modal */}
      {swapModal&&(
        <div className="modal" onClick={()=>setSwapModal(null)}>
          <div className="modal-box" onClick={e=>e.stopPropagation()}>
            <div className="modal-title">Replace {swapModal.slot==="A"?tourn.rounds[swapModal.ri]?.matches[swapModal.mi]?.teamA:tourn.rounds[swapModal.ri]?.matches[swapModal.mi]?.teamB}</div>
            <div style={{fontSize:12,color:C.txtD,marginBottom:12}}>Select replacement team:</div>
            {teams.map(t=>(
              <div key={t.name} className="sel-item" onClick={()=>doSwapTeam(t.name)}>
                <div style={{flex:1}}><div style={{fontWeight:700}}>{t.name}</div><div style={{fontSize:11,color:C.txtM}}>{t.members.join(" & ")}</div></div>
              </div>
            ))}
            <button className="btn bo bfull" style={{marginTop:8}} onClick={()=>setSwapModal(null)}>Cancel</button>
          </div>
        </div>
      )}

      {/* Bye modal */}
      {byeModal&&(
        <div className="modal" onClick={()=>setByeModal(null)}>
          <div className="modal-box" onClick={e=>e.stopPropagation()}>
            <div className="modal-title">Assign BYE</div>
            <div style={{fontSize:13,color:C.txtM,marginBottom:14}}>Which team gets the bye (auto-advances)?</div>
            {["A","B"].map(slot=>{
              const m=tourn.rounds[byeModal.ri]?.matches[byeModal.mi];
              const name=slot==="A"?m?.teamA:m?.teamB;
              return <div key={slot} className="sel-item" onClick={()=>assignBye(byeModal.ri,byeModal.mi,slot==="A"?"B":"A")}>
                🎟️ {name} gets the BYE
              </div>;
            })}
            <button className="btn bo bfull" style={{marginTop:8}} onClick={()=>setByeModal(null)}>Cancel</button>
          </div>
        </div>
      )}
    </>
  );
}

// ─── STATS ───────────────────────────────────────────────────────────────────
function StatsView({history,players}){
  const [tab,setTab]=useState("players");
  const {pS,tS}=computeStats(history,players);
  const acs=[C.sA,C.sB,C.gr,C.acc,C.purple,C.orange,"#00d4aa"];
  if(!history.length)return <div className="empty"><div className="ei">📊</div><div className="et">No data yet</div><div className="es">Play matches to see stats</div></div>;
  return (
    <>
      <div className="tabs">
        <button className={`tab ${tab==="players"?"on":""}`} onClick={()=>setTab("players")}>Players</button>
        <button className={`tab ${tab==="teams"?"on":""}`} onClick={()=>setTab("teams")}>Teams</button>
      </div>
      {tab==="players"&&Object.entries(pS).filter(([,s])=>s.matches>0).sort((a,b)=>b[1].wins-a[1].wins).map(([name,s],i)=>{
        const wr=s.matches?Math.round(s.wins/s.matches*100):0,c=acs[i%acs.length];
        return (
          <div key={name} className="psc">
            <div className="psc-top">
              <div className="ava" style={{background:c+"28",color:c,border:`2px solid ${c}40`}}>{name[0].toUpperCase()}</div>
              <div style={{flex:1}}><div style={{fontFamily:"Syne,sans-serif",fontSize:14,fontWeight:800}}>{name}</div><div style={{fontSize:11,color:C.txtM}}>{s.wins}W – {s.losses}L · {s.matches} matches</div></div>
              <div style={{textAlign:"right"}}><div style={{fontFamily:"Syne,sans-serif",fontSize:20,fontWeight:800,color:c}}>{wr}%</div><div style={{fontSize:9,color:C.txtD}}>WIN RATE</div></div>
            </div>
            <div className="wrb"><div className="wrf" style={{width:`${wr}%`}}/></div>
            <div className="sg" style={{marginTop:8}}>
              <div className="sb2"><div className="sv" style={{color:C.win}}>{s.wins}</div><div className="sl">Wins</div></div>
              <div className="sb2"><div className="sv">{s.setsWon}</div><div className="sl">Sets</div></div>
              <div className="sb2"><div className="sv" style={{color:C.gr}}>{s.pointsWon}</div><div className="sl">Pts</div></div>
            </div>
          </div>
        );
      })}
      {tab==="teams"&&Object.entries(tS).sort((a,b)=>b[1].wins-a[1].wins).map(([name,s])=>{
        const tot=s.wins+s.losses,wr=tot?Math.round(s.wins/tot*100):0;
        return (
          <div key={name} className="psc">
            <div className="psc-top">
              <div className="ava" style={{background:C.accd,color:C.acc,border:`2px solid ${C.acc}40`}}>🏸</div>
              <div style={{flex:1}}><div style={{fontFamily:"Syne,sans-serif",fontSize:14,fontWeight:800}}>{name}</div><div style={{fontSize:11,color:C.txtM}}>{s.players?.join(" & ")} · {tot} matches</div></div>
              <div style={{textAlign:"right"}}><div style={{fontFamily:"Syne,sans-serif",fontSize:20,fontWeight:800,color:C.acc}}>{wr}%</div><div style={{fontSize:9,color:C.txtD}}>WIN RATE</div></div>
            </div>
            <div className="wrb"><div className="wrf" style={{width:`${wr}%`}}/></div>
            <div className="sg" style={{marginTop:8}}>
              <div className="sb2"><div className="sv" style={{color:C.win}}>{s.wins}</div><div className="sl">Wins</div></div>
              <div className="sb2"><div className="sv">{s.setsWon}</div><div className="sl">Sets</div></div>
              <div className="sb2"><div className="sv" style={{color:C.gr}}>{s.pointsWon}</div><div className="sl">Pts</div></div>
            </div>
          </div>
        );
      })}
    </>
  );
}

// ─── LOBBY ───────────────────────────────────────────────────────────────────
function Lobby({onJoin}){
  const [mode,setMode]=useState("home");
  const [rName,setRName]=useState("");
  const [refC,setRefC]=useState("");
  const [viewC,setViewC]=useState("");
  const [joinC,setJoinC]=useState("");
  const [passC,setPassC]=useState("");
  const [err,setErr]=useState("");
  const [loading,setLoading]=useState(false);

  const withTimeout=(promise,ms=8000)=>Promise.race([promise,new Promise((_,rej)=>setTimeout(()=>rej(new Error("timeout")),ms))]);

  const create=async()=>{
    const r=rName.trim().toLowerCase().replace(/\s+/g,"-");
    if(!r){setErr("Enter a room name");return;}
    if(!refC.trim()){setErr("Set a referee password");return;}
    setLoading(true);setErr("");
    try{
      const ex=await withTimeout(getRoomMeta(r));
      if(ex){setErr("Room name taken, try another");setLoading(false);return;}
      await withTimeout(saveRoomMeta(r,{name:rName.trim(),refCode:refC.trim(),viewCode:viewC.trim()||"",createdAt:Date.now()}));
      onJoin({room:r,role:"referee",roomDisplayName:rName.trim()});
    }catch(e){
      setErr("Connection failed — check internet and try again");
    }
    setLoading(false);
  };
  const join=async()=>{
    const r=joinC.trim().toLowerCase().replace(/\s+/g,"-");
    if(!r){setErr("Enter a room code");return;}
    setLoading(true);setErr("");
    try{
      const meta=await withTimeout(getRoomMeta(r));
      if(!meta){setErr("Room not found");setLoading(false);return;}
      const isRef=passC.trim()===meta.refCode;
      const isView=!meta.viewCode||passC.trim()===meta.viewCode;
      if(!isRef&&!isView){setErr("Wrong access code");setLoading(false);return;}
      onJoin({room:r,role:isRef?"referee":"spectator",roomDisplayName:meta.name||r});
    }catch(e){
      setErr("Connection failed — check internet and try again");
    }
    setLoading(false);
  };

  return (
    <div className="lobby">
      <div className="llogo">🏸</div>
      <div className="ltitle">SHUTTLE<span style={{color:C.gr}}>SCORE</span></div>
      <div className="lsub">Live badminton tracker</div>
      {mode==="home"&&(
        <div style={{width:"100%",maxWidth:300,display:"flex",flexDirection:"column",gap:9}}>
          <button className="btn bg bfull" style={{padding:14}} onClick={()=>setMode("create")}>＋ Create room</button>
          <button className="btn bo bfull" style={{padding:14}} onClick={()=>setMode("join")}>→ Join room</button>
          <div style={{fontSize:11,color:C.txtD,textAlign:"center",marginTop:4}}>Each friend group gets their own private room with separate history & stats.</div>
        </div>
      )}
      {mode==="create"&&(
        <div className="rcard">
          <div className="rcardT">Create Room</div>
          <div className="lbl">Room name</div>
          <input className="inp" value={rName} onChange={e=>setRName(e.target.value)} placeholder="e.g. Sunday Gang" style={{marginBottom:9}}/>
          <div className="lbl">Referee password *</div>
          <input className="inp" type="password" value={refC} onChange={e=>setRefC(e.target.value)} placeholder="Only you know this" style={{marginBottom:9}}/>
          <div className="lbl">Spectator code <span style={{color:C.txtD}}>(optional)</span></div>
          <input className="inp" value={viewC} onChange={e=>setViewC(e.target.value)} placeholder="Leave blank = open to all" style={{marginBottom:13}}/>
          {err&&<div style={{color:C.loss,fontSize:12,marginBottom:8}}>⚠ {err}</div>}
          <button className="btn bg bfull" onClick={create} disabled={loading}>{loading?"Creating…":"Create →"}</button>
          <button className="btn bo bfull" style={{marginTop:7}} onClick={()=>{setMode("home");setErr("");}}>← Back</button>
        </div>
      )}
      {mode==="join"&&(
        <div className="rcard">
          <div className="rcardT">Join Room</div>
          <div className="lbl">Room code</div>
          <input className="inp" value={joinC} onChange={e=>setJoinC(e.target.value)} placeholder="e.g. sunday-gang" style={{marginBottom:9}}/>
          <div className="lbl">Access code</div>
          <input className="inp" type="password" value={passC} onChange={e=>setPassC(e.target.value)} placeholder="Referee or spectator code" style={{marginBottom:13}}/>
          {err&&<div style={{color:C.loss,fontSize:12,marginBottom:8}}>⚠ {err}</div>}
          <button className="btn bg bfull" onClick={join} disabled={loading}>{loading?"Checking…":"Join →"}</button>
          <button className="btn bo bfull" style={{marginTop:7}} onClick={()=>{setMode("home");setErr("");}}>← Back</button>
        </div>
      )}
    </div>
  );
}

// ─── MAIN ────────────────────────────────────────────────────────────────────
export default function App(){
  const [session,setSession]=useState(null);
  const [view,setView]=useState("match");
  const [setupStep,setSetupStep]=useState(0);
  const [toastMsg,setToastMsg]=useState(null);
  const [syncSt,setSyncSt]=useState("spin");

  const [players,setPlayers]=useState([]);
  const [teams,setTeams]=useState([]);
  const [history,setHistory]=useState([]);

  const [teamA,setTeamA]=useState({name:"Red",players:[],type:"singles"});
  const [teamB,setTeamB]=useState({name:"Blue",players:[],type:"singles"});
  const [scoreA,setScoreA]=useState(0);
  const [scoreB,setScoreB]=useState(0);
  const [serving,setServing]=useState("A");
  const [sets,setSets]=useState([]);
  const [winner,setWinner]=useState(null);
  const [lastPt,setLastPt]=useState(null);
  const [matchSTW,setMatchSTW]=useState(2);
  const [matchStatus,setMatchStatus]=useState("idle");

  const [matchType,setMatchType]=useState("singles");
  const [setsToWin,setSetsToWin]=useState(2);
  const [tAName,setTAName]=useState("Red");
  const [tBName,setTBName]=useState("Blue");
  const [selA,setSelA]=useState([]);
  const [selB,setSelB]=useState([]);
  const maxS=matchType==="doubles"?2:1;
  const [doublesTeams,setDoublesTeams]=useState([]);
  const [doublesReady,setDoublesReady]=useState(false);

  const toast$=msg=>{setToastMsg(msg);setTimeout(()=>setToastMsg(null),2500);};
  const isRef=session?.role==="referee";
  const room=session?.room;

  useEffect(()=>{
    if(!room)return;
    const u=[];
    u.push(subscribePlayers(room,p=>{setPlayers(p);setSyncSt("ok");}));
    u.push(subscribeTeams(room,t=>{setTeams(t);setSyncSt("ok");}));
    u.push(subscribeHistory(room,h=>{setHistory(h);setSyncSt("ok");}));
    u.push(subscribeLiveMatch(room,d=>{
      setSyncSt("ok");
      if(!isRef){
        setTeamA(d.teamA||teamA);setTeamB(d.teamB||teamB);
        setScoreA(d.scoreA??0);setScoreB(d.scoreB??0);
        setServing(d.serving||"A");setSets(d.sets||[]);
        setWinner(d.winner||null);setMatchSTW(d.setsToWin||2);
        setMatchStatus(d.status||"idle");
      }
    }));
    return ()=>u.forEach(f=>f());
  },[room,isRef]);// eslint-disable-line

  const push=useCallback((state)=>{
    if(!room)return;
    setSyncSt("spin");
    saveLiveMatch(room,state).then(()=>setSyncSt("ok")).catch(()=>setSyncSt("err"));
  },[room]);

  const handleScore=useCallback((side)=>{
    if(winner||!isRef)return;
    setLastPt(side);
    const nA=scoreA+(side==="A"?1:0),nB=scoreB+(side==="B"?1:0);
    const g=gw(nA,nB);
    if(g){
      const ns=[...sets,{scoreA:nA,scoreB:nB,winner:g}];setSets(ns);
      const m=mw(ns,matchSTW);
      if(m){
        setWinner(m);
        const nh=[{teamA,teamB,sets:ns,winner:m,type:teamA.type,date:Date.now()},...history];
        setHistory(nh);saveHistory(room,nh);setMatchStatus("finished");
        push({teamA,teamB,scoreA:nA,scoreB:nB,sets:ns,serving,winner:m,setsToWin:matchSTW,status:"finished"});
      }else{
        setScoreA(0);setScoreB(0);setServing(g);
        push({teamA,teamB,scoreA:0,scoreB:0,sets:ns,serving:g,winner:null,setsToWin:matchSTW,status:"live"});
      }
    }else{
      setScoreA(nA);setScoreB(nB);setServing(side);
      push({teamA,teamB,scoreA:nA,scoreB:nB,sets,serving:side,winner:null,setsToWin:matchSTW,status:"live"});
    }
  },[scoreA,scoreB,sets,winner,teamA,teamB,matchSTW,serving,history,isRef,push,room]);

  const undoPoint=()=>{
    if(!isRef||winner)return;
    let nA=scoreA,nB=scoreB,ns=sets;
    if(scoreA===0&&scoreB===0&&sets.length>0){
      const prev=sets[sets.length-1];ns=sets.slice(0,-1);
      nA=prev.scoreA-(lastPt==="A"?1:0);nB=prev.scoreB-(lastPt==="B"?1:0);
      setSets(ns);setScoreA(nA);setScoreB(nB);
    }else{
      if(lastPt==="A"){nA=Math.max(0,scoreA-1);setScoreA(nA);}
      else if(lastPt==="B"){nB=Math.max(0,scoreB-1);setScoreB(nB);}
    }
    push({teamA,teamB,scoreA:nA,scoreB:nB,sets:ns,serving,winner:null,setsToWin:matchSTW,status:"live"});
  };

  const resetMatch=()=>{
    setScoreA(0);setScoreB(0);setSets([]);setWinner(null);setServing("A");setLastPt(null);setMatchStatus("idle");
    if(isRef)push({teamA,teamB,scoreA:0,scoreB:0,sets:[],serving:"A",winner:null,setsToWin:matchSTW,status:"idle"});
  };

  // Called from tournament "▶ Start Match"
  const onStartMatchFromTourn=(config)=>{
    setTeamA(config.teamA);setTeamB(config.teamB);setMatchSTW(config.setsToWin||2);
    setScoreA(0);setScoreB(0);setSets([]);setWinner(null);setServing("A");setLastPt(null);setMatchStatus("live");
    push({teamA:config.teamA,teamB:config.teamB,scoreA:0,scoreB:0,sets:[],serving:"A",winner:null,setsToWin:config.setsToWin||2,status:"live"});
    setView("match");toast$("Match started! Go to Match tab 🏸");
  };

  const startMatch=()=>{
    if(!selA.length||!selB.length){toast$("Select players for both sides");return;}
    const tA={name:tAName||selA.join(" & "),players:selA,type:matchType};
    const tB={name:tBName||selB.join(" & "),players:selB,type:matchType};
    setTeamA(tA);setTeamB(tB);setMatchSTW(setsToWin);
    setScoreA(0);setScoreB(0);setSets([]);setWinner(null);setServing("A");setLastPt(null);setMatchStatus("live");
    push({teamA:tA,teamB:tB,scoreA:0,scoreB:0,sets:[],serving:"A",winner:null,setsToWin,status:"live"});
    setView("match");setSetupStep(0);
  };

  const toggleSel=(side,name)=>{
    if(side==="A")setSelA(a=>a.includes(name)?a.filter(x=>x!==name):[...a,name]);
    else setSelB(b=>b.includes(name)?b.filter(x=>x!==name):[...b,name]);
  };

  if(!session)return <><style>{css}</style><Lobby onJoin={s=>{setSession(s);setSyncSt("spin");}}/></>;

  const navItems=[
    {id:"match",icon:"🏸",label:"Match"},
    {id:"setup",icon:"⚙️",label:"Setup"},
    {id:"registry",icon:"👥",label:"Registry"},
    {id:"tournament",icon:"🏆",label:"Tourn."},
    {id:"stats",icon:"📊",label:"Stats"},
    {id:"history",icon:"📋",label:"History"},
  ];

  return (
    <>
      <style>{css}</style>
      <div className="app">
        <div className="hdr">
          <div className="lbox">🏸</div>
          <div><div className="ltxt">SHUTTLE<span style={{color:C.gr}}>SCORE</span></div><div className="lsub">Live Tracker</div></div>
          <div className="hr">
            <div className="sync-pill"><div className={`sdot ${syncSt}`}/><span>{syncSt==="ok"?"Live":syncSt==="err"?"Offline":"Sync…"}</span></div>
            <div className="room-chip"><span>#{session.roomDisplayName}</span></div>
            {isRef&&<div style={{background:C.grd,border:`1px solid ${C.gr}44`,padding:"3px 8px",borderRadius:20,fontSize:9,fontWeight:700,color:C.gr}}>✏️ Ref</div>}
            <button className="btn bxs bo" onClick={()=>{setSession(null);setSyncSt("spin");}}>⏏</button>
          </div>
        </div>

        {/* MATCH */}
        {view==="match"&&(
          <>
            {!isRef&&matchStatus==="live"&&<div className="live-bar"><div className="ldot"/><span>LIVE — updates automatically</span></div>}
            <Scoreboard tA={teamA} tB={teamB} sA={scoreA} sB={scoreB} sets={sets} serving={serving} setsToWin={matchSTW}/>
            <div style={{position:"relative"}}>
              <Court onScore={handleScore} serving={serving} disabled={!!winner||!isRef}/>
              {!isRef&&<div className="locked">👀</div>}
            </div>
            {isRef?(
              <div className="ctrl">
                <button className="btn br bsm" onClick={undoPoint} disabled={scoreA===0&&scoreB===0&&!sets.length}>↩ Undo</button>
                <button className="btn bo bsm" onClick={()=>setServing(s=>s==="A"?"B":"A")}>🔄 Serve</button>
                <div style={{flex:1}}/>
                <button className="btn bo bsm" onClick={resetMatch}>↺ Reset</button>
                <button className="btn by bsm" onClick={()=>{setView("setup");setSetupStep(0);}}>+ Setup</button>
              </div>
            ):(
              <div style={{textAlign:"center",color:C.txtD,fontSize:12,padding:"8px 0"}}>👀 Spectator — referee controls score</div>
            )}
            {isRef&&<div style={{textAlign:"center",color:C.txtD,fontSize:10,marginTop:-2}}>Tap court half to score · Gold dot = server</div>}
          </>
        )}

        {/* SETUP */}
        {view==="setup"&&!isRef&&<div className="card p16" style={{textAlign:"center",padding:"40px 16px"}}><div style={{fontSize:36,marginBottom:9}}>🔒</div><div style={{fontFamily:"Syne,sans-serif",fontSize:16,fontWeight:800,marginBottom:5}}>Referee Only</div><div style={{color:C.txtD,fontSize:12}}>Only the referee can set up matches.</div></div>}
        {view==="setup"&&isRef&&(
          <>
            {setupStep===0&&(
              <div className="card p14">
                <div className="ey">Match Format</div>
                <div className="cfgr">
                  <button className={`cfgo ${matchType==="singles"?"on":""}`} onClick={()=>{setMatchType("singles");setSelA([]);setSelB([]);}}>🏃 Singles<br/><span style={{fontSize:11,fontWeight:400}}>1 vs 1</span></button>
                  <button className={`cfgo ${matchType==="doubles"?"on":""}`} onClick={()=>{setMatchType("doubles");setSelA([]);setSelB([]);}}>👥 Doubles<br/><span style={{fontSize:11,fontWeight:400}}>2 vs 2</span></button>
                </div>
                <div className="ey" style={{marginTop:13}}>Best Of</div>
                <div className="cfgr">
                  {[1,2,3].map(n=><button key={n} className={`cfgo ${setsToWin===n?"on":""}`} onClick={()=>setSetsToWin(n)}>{n===1?"1 Set":n===2?"Best of 3":"Best of 5"}<br/><span style={{fontSize:10,fontWeight:400}}>{n} to win</span></button>)}
                </div>
                <button className="btn bg bfull" style={{marginTop:13}} onClick={()=>setSetupStep(1)}>Next: Pick Players →</button>
              </div>
            )}
            {setupStep===1&&(
              <div className="card p14">
                <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:12}}>
                  <button className="btn bo bsm" onClick={()=>setSetupStep(0)}>← Back</button>
                  <div className="ey" style={{marginBottom:0}}>Pick Players · {matchType==="doubles"?"2/side":"1/side"}</div>
                </div>
                <div style={{display:"flex",gap:6,marginBottom:9}}>
                  <div style={{flex:1,background:C.sAd,border:`1px solid ${C.sA}44`,borderRadius:9,padding:"7px 10px"}}>
                    <div className="lbl" style={{color:C.sA}}>Side A · {selA.length}/{maxS}</div>
                    <div style={{fontWeight:700,fontSize:12,minHeight:16}}>{selA.join(" & ")||"—"}</div>
                  </div>
                  <div style={{flex:1,background:C.sBd,border:`1px solid ${C.sB}44`,borderRadius:9,padding:"7px 10px"}}>
                    <div className="lbl" style={{color:C.sB}}>Side B · {selB.length}/{maxS}</div>
                    <div style={{fontWeight:700,fontSize:12,minHeight:16,textAlign:"right"}}>{selB.join(" & ")||"—"}</div>
                  </div>
                </div>
                {players.length===0?<div className="empty" style={{padding:"16px 0"}}><div className="ei">👤</div><div className="et">No players</div><div className="es">Add in Registry tab</div></div>:(
                  <div style={{display:"flex",flexDirection:"column",gap:5,marginBottom:11}}>
                    {players.map(p=>{
                      const iA=selA.includes(p),iB=selB.includes(p);
                      return (
                        <div key={p} style={{display:"flex",alignItems:"center",gap:6,background:C.surf,borderRadius:9,padding:"7px 10px",border:`1px solid ${iA?C.sA+"55":iB?C.sB+"55":C.bdr}`}}>
                          <div style={{flex:1,fontWeight:600,fontSize:12}}>{p}</div>
                          <button className="btn bsm" style={iA?{background:C.sA,color:"#fff"}:{background:C.card,border:`1px solid ${C.bdr}`,color:C.txt}} onClick={()=>toggleSel("A",p)} disabled={iB||(!iA&&selA.length>=maxS)}>A</button>
                          <button className="btn bsm" style={iB?{background:C.sB,color:"#fff"}:{background:C.card,border:`1px solid ${C.bdr}`,color:C.txt}} onClick={()=>toggleSel("B",p)} disabled={iA||(!iB&&selB.length>=maxS)}>B</button>
                        </div>
                      );
                    })}
                  </div>
                )}
                <button className="btn bg bfull" onClick={()=>setSetupStep(2)} disabled={!selA.length||!selB.length}>Next: Team Names →</button>
              </div>
            )}
            {setupStep===2&&(
              <div className="card p14">
                <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:12}}>
                  <button className="btn bo bsm" onClick={()=>setSetupStep(1)}>← Back</button>
                  <div className="ey" style={{marginBottom:0}}>Team Names</div>
                </div>
                <div style={{marginBottom:9}}><div className="lbl" style={{color:C.sA}}>Side A – {selA.join(" & ")}</div><input className="inp" value={tAName} onChange={e=>setTAName(e.target.value)} placeholder="Team name…"/></div>
                <div style={{marginBottom:13}}><div className="lbl" style={{color:C.sB}}>Side B – {selB.join(" & ")}</div><input className="inp" value={tBName} onChange={e=>setTBName(e.target.value)} placeholder="Team name…"/></div>
                <div style={{background:C.surf,borderRadius:9,padding:"9px 11px",marginBottom:13,fontSize:11,color:C.txtM,display:"flex",justifyContent:"space-between"}}>
                  <span>{matchType==="doubles"?"2v2 Doubles":"1v1 Singles"}</span>
                  <span style={{color:C.txt,fontWeight:700}}>{setsToWin===1?"1 Set":setsToWin===2?"Best of 3":"Best of 5"}</span>
                </div>
                <button className="btn by bfull" onClick={startMatch}>▶ Go Live</button>
              </div>
            )}
          </>
        )}

        {/* REGISTRY */}
        {view==="registry"&&(
          <Registry
            players={players} teams={teams} isRef={isRef}
            onSavePlayers={p=>{setPlayers(p);savePlayers(room,p);}}
            onSaveTeams={t=>{setTeams(t);saveTeams(room,t);}}
          />
        )}

        {/* TOURNAMENT */}
        {view==="tournament"&&(
          <TournamentView
            teams={teams} players={players} room={room} isRef={isRef}
            onStartMatch={onStartMatchFromTourn}
            history={history} toast$={toast$}
          />
        )}

        {/* STATS */}
        {view==="stats"&&<StatsView history={history} players={players}/>}

        {/* HISTORY */}
        {view==="history"&&(
          history.length===0
            ?<div className="empty"><div className="ei">📋</div><div className="et">No matches yet</div></div>
            :history.map((m,i)=>(
              <div key={i} className="mc">
                <div className="mc-top">
                  <div className="mcs"><div className="mcn" style={{color:C.sA}}>{m.teamA.name}</div><div className="mcp">{m.teamA.players.join(" · ")}</div><div className="mcpi"><div className={`rpip ${m.winner==="A"?"w":"l"}`}/></div></div>
                  <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3,minWidth:28}}>
                    <div style={{fontSize:9,color:C.txtD,fontWeight:700,letterSpacing:1}}>VS</div>
                    <div className="mcb t">{m.type==="doubles"?"2v2":"1v1"}</div>
                  </div>
                  <div className="mcs mcs-r"><div className="mcn" style={{color:C.sB}}>{m.teamB.name}</div><div className="mcp">{m.teamB.players.join(" · ")}</div><div className="mcpi mcpi-r"><div className={`rpip ${m.winner==="B"?"w":"l"}`}/></div></div>
                </div>
                <div className="mc-sets">
                  <span style={{fontSize:9,color:C.txtD,fontWeight:700,marginRight:3,letterSpacing:.5,textTransform:"uppercase"}}>Sets</span>
                  {m.sets.map((s,j)=>(
                    <div key={j} className="spill">
                      <span style={{color:s.winner==="A"?C.sA:C.txtD,fontWeight:s.winner==="A"?700:400}}>{s.scoreA}</span>
                      <span style={{color:C.txtD}}>–</span>
                      <span style={{color:s.winner==="B"?C.sB:C.txtD,fontWeight:s.winner==="B"?700:400}}>{s.scoreB}</span>
                    </div>
                  ))}
                  <div style={{flex:1}}/><div className="mcb w">🏆 {m.winner==="A"?m.teamA.name:m.teamB.name}</div>
                </div>
                {m.date&&<div style={{fontSize:9,color:C.txtD,marginTop:4}}>{new Date(m.date).toLocaleString()}</div>}
              </div>
            ))
        )}
      </div>

      {/* BOT NAV */}
      <div className="bot-nav">
        {navItems.map(n=>(
          <button key={n.id} className={`nbn ${view===n.id?"on":""}`} onClick={()=>setView(n.id)}>
            <span className="ni">{n.icon}</span>{n.label}
          </button>
        ))}
      </div>

      {/* WINNER */}
      {winner&&(
        <div className="ov">
          <div className="wm">
            <div className="tr">🏆</div>
            <div style={{fontSize:10,fontWeight:700,letterSpacing:2,color:C.txtD,textTransform:"uppercase",marginBottom:3}}>Winner</div>
            <div style={{fontFamily:"Syne,sans-serif",fontSize:28,fontWeight:800,letterSpacing:-1,color:winner==="A"?C.sA:C.sB,marginBottom:2}}>{(winner==="A"?teamA:teamB).name}</div>
            <div style={{color:C.txtM,fontSize:12,marginBottom:5}}>{(winner==="A"?teamA:teamB).players.join(" & ")}</div>
            <div className="set-row" style={{marginBottom:16}}>
              {sets.map((s,i)=>(
                <div key={i} className="spill"><span className="sn">S{i+1}</span>
                  <span style={{color:s.winner==="A"?C.sA:C.txtD,fontWeight:s.winner==="A"?700:400}}>{s.scoreA}</span>
                  <span style={{color:C.txtD}}>–</span>
                  <span style={{color:s.winner==="B"?C.sB:C.txtD,fontWeight:s.winner==="B"?700:400}}>{s.scoreB}</span>
                </div>
              ))}
            </div>
            <div style={{display:"flex",gap:7,justifyContent:"center"}}>
              {isRef&&<><button className="btn bo" onClick={()=>{setWinner(null);resetMatch();}}>Again</button><button className="btn by" onClick={()=>{setWinner(null);resetMatch();setView("setup");setSetupStep(0);}}>New</button></>}
              {!isRef&&<button className="btn bo" onClick={()=>setWinner(null)}>Close</button>}
            </div>
          </div>
        </div>
      )}

      {toastMsg&&<div className="toast">{toastMsg}</div>}
    </>
  );
}
